
import React from 'react';

interface WelcomeScreenProps {
  onStart: () => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onStart }) => {
  return (
    <div className="flex flex-col items-center justify-center h-screen p-4 text-center">
      <div className="absolute top-0 left-0 w-full h-full bg-black opacity-30"></div>
      <div className="relative z-10 glassmorphism p-8 md:p-12 rounded-2xl border-2 border-cyan-400/50 shadow-2xl shadow-cyan-500/20">
        <h1 className="text-4xl md:text-6xl font-bold mb-4 neon-text animate-pulse">
          HACK NÃO QUIZ PRO
        </h1>
        <p className="text-lg md:text-xl text-gray-200 mb-8 max-w-2xl">
          Chào mừng đến với thử thách trí tuệ đỉnh cao. Bạn có 50 câu hỏi để chứng tỏ bản thân. Hãy cẩn thận, mỗi câu hỏi đều là một cái bẫy.
        </p>
        <p className="text-yellow-300 mb-8 font-bold text-sm">
          ⚠️ CẢNH BÁO: Không được chuyển tab hoặc thoát khỏi màn hình trong lúc làm bài. Hệ thống sẽ phát hiện gian lận!
        </p>
        <button
          onClick={onStart}
          className="bg-cyan-500 text-gray-900 font-bold py-3 px-8 rounded-lg text-xl hover:bg-cyan-400 transform hover:scale-105 transition-all duration-300 ease-in-out neon-border"
        >
          Bắt đầu thử thách
        </button>
      </div>
    </div>
  );
};

export default WelcomeScreen;
