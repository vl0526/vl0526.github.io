
import React, { useState, useEffect } from 'react';
import { Question } from '../types';
import { usePageVisibility } from '../hooks/usePageVisibility';

interface QuizScreenProps {
  questions: Question[];
  onFinish: (answers: (number | null)[]) => void;
  onCheat: () => void;
}

const QuizScreen: React.FC<QuizScreenProps> = ({ questions, onFinish, onCheat }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<(number | null)[]>(Array(questions.length).fill(null));
  const [animate, setAnimate] = useState(false);

  usePageVisibility(onCheat);

  const handleSelectAnswer = (optionIndex: number) => {
    const newAnswers = [...userAnswers];
    newAnswers[currentQuestionIndex] = optionIndex;
    setUserAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setAnimate(true);
      setTimeout(() => {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
        setAnimate(false);
      }, 300);
    }
  };
  
  const handlePrev = () => {
      if(currentQuestionIndex > 0) {
        setAnimate(true);
        setTimeout(() => {
            setCurrentQuestionIndex(currentQuestionIndex - 1);
            setAnimate(false);
        }, 300);
      }
  }

  const handleSubmit = () => {
    onFinish(userAnswers);
  };

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  return (
    <div className="flex items-center justify-center min-h-screen p-4">
      <div className={`w-full max-w-3xl glassmorphism p-6 md:p-8 rounded-2xl shadow-2xl transition-all duration-300 ${animate ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}>
        {/* Progress Bar */}
        <div>
          <div className="flex justify-between mb-1">
            <span className="text-base font-medium text-cyan-300">Câu hỏi {currentQuestionIndex + 1} / {questions.length}</span>
            <span className="text-sm font-medium text-cyan-300">{Math.round(progress)}%</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2.5">
            <div className="bg-cyan-400 h-2.5 rounded-full transition-all duration-500" style={{ width: `${progress}%` }}></div>
          </div>
        </div>

        <div className="mt-8">
          <h2 className="text-2xl md:text-3xl font-bold mb-6 text-center text-white">{currentQuestion.questionText}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {currentQuestion.options.map((option, index) => {
              const isSelected = userAnswers[currentQuestionIndex] === index;
              return (
                <button
                  key={index}
                  onClick={() => handleSelectAnswer(index)}
                  className={`p-4 rounded-lg text-left transition-all duration-200 border-2 ${
                    isSelected
                      ? 'bg-cyan-500 border-cyan-300 text-white font-bold scale-105 shadow-lg shadow-cyan-500/30'
                      : 'bg-white/10 border-transparent hover:bg-white/20 hover:border-cyan-400'
                  }`}
                >
                  {option}
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex justify-between mt-8">
            <button
              onClick={handlePrev}
              disabled={currentQuestionIndex === 0}
              className="bg-gray-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-gray-500 transition-colors disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed"
            >
              Trước
            </button>
            {currentQuestionIndex < questions.length - 1 ? (
              <button
                onClick={handleNext}
                className="bg-indigo-500 text-white font-bold py-2 px-6 rounded-lg hover:bg-indigo-400 transition-colors"
              >
                Tiếp theo
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                className="bg-green-500 text-white font-bold py-2 px-6 rounded-lg hover:bg-green-400 transition-colors shadow-lg shadow-green-500/30 animate-pulse"
              >
                Nộp bài
              </button>
            )}
        </div>
      </div>
    </div>
  );
};

export default QuizScreen;
