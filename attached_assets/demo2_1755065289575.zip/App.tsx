
import React, { useState, useEffect, useCallback } from 'react';
import { GameState, Question } from './types';
import { ADMIN_IP, CHEAT_WARNING_LIMIT } from './constants';
import { initialQuestions } from './data/questions';

import WelcomeScreen from './components/WelcomeScreen';
import QuizScreen from './components/QuizScreen';
import ResultsScreen from './components/ResultsScreen';
import BannedScreen from './components/BannedScreen';
import AdminPanel from './components/AdminPanel';
import YoutubeBackground from './components/YoutubeBackground';
import { IconWarning } from './components/icons';

const App: React.FC = () => {
    const [gameState, setGameState] = useState<GameState>(GameState.Welcome);
    const [questions, setQuestions] = useState<Question[]>(initialQuestions);
    const [userAnswers, setUserAnswers] = useState<(number | null)[]>([]);
    const [isAdmin, setIsAdmin] = useState(false);
    
    // Anti-cheat state
    const [cheatWarnings, setCheatWarnings] = useState(0);
    const [isBanned, setIsBanned] = useState(false);

    // Real-time simulation state
    const [notification, setNotification] = useState<string | null>(null);
    const [showConfetti, setShowConfetti] = useState(false);

    // Simulate IP check on component mount
    useEffect(() => {
        // In a real app, you would fetch the user's IP from a service.
        // For this example, we simulate it.
        // To test admin, change this to ADMIN_IP
        const currentUserIp = '171.224.181.202'; // '127.0.0.1'; 
        if (currentUserIp === ADMIN_IP) {
            setIsAdmin(true);
        }

        // Check for persisted ban status
        const savedBanStatus = localStorage.getItem('isBanned');
        if (savedBanStatus === 'true') {
            setIsBanned(true);
            setGameState(GameState.Banned);
        }
    }, []);

    const handleStartQuiz = () => {
        setCheatWarnings(0);
        setUserAnswers(Array(questions.length).fill(null));
        setGameState(GameState.Playing);
    };

    const handleFinishQuiz = (answers: (number | null)[]) => {
        setUserAnswers(answers);
        setGameState(GameState.Finished);
    };

    const handleRestartQuiz = () => {
        setGameState(GameState.Welcome);
    };
    
    const handleUnban = () => {
        if (isAdmin) {
            setIsBanned(false);
            localStorage.removeItem('isBanned');
            setGameState(GameState.Welcome);
            handleSendNotification("Tài khoản của bạn đã được Admin mở khóa.");
        }
    };

    const handleCheatAttempt = useCallback(() => {
        if(gameState !== GameState.Playing || isBanned) return;

        const newWarningCount = cheatWarnings + 1;
        setCheatWarnings(newWarningCount);
        
        if (newWarningCount > CHEAT_WARNING_LIMIT) {
            setIsBanned(true);
            localStorage.setItem('isBanned', 'true');
            setGameState(GameState.Banned);
        } else {
            setNotification(`CẢNH CÁO ${newWarningCount}/${CHEAT_WARNING_LIMIT}: Không rời khỏi trang làm bài!`);
        }
    }, [cheatWarnings, gameState, isBanned]);

    const handleSendNotification = (message: string) => {
        setNotification(message);
    };
    
    useEffect(() => {
        if(notification) {
            const timer = setTimeout(() => setNotification(null), 5000);
            return () => clearTimeout(timer);
        }
    }, [notification]);

    const handleTriggerAnimation = () => {
        setShowConfetti(true);
        setTimeout(() => setShowConfetti(false), 5000); // Animation lasts 5 seconds
    };

    const renderGameState = () => {
        switch (gameState) {
            case GameState.Playing:
                return <QuizScreen questions={questions} onFinish={handleFinishQuiz} onCheat={handleCheatAttempt} />;
            case GameState.Finished:
                return <ResultsScreen questions={questions} userAnswers={userAnswers} onRestart={handleRestartQuiz} />;
            case GameState.Banned:
                return <BannedScreen isAdmin={isAdmin} onUnban={handleUnban}/>;
            case GameState.Welcome:
            default:
                return <WelcomeScreen onStart={handleStartQuiz} />;
        }
    };
    
    return (
        <>
            <div className="youtube-bg-container">
                <YoutubeBackground />
            </div>
            <main className="relative z-10">
                {renderGameState()}
            </main>
            
            {isAdmin && <AdminPanel questions={questions} setQuestions={setQuestions} onSendNotification={handleSendNotification} onTriggerAnimation={handleTriggerAnimation} />}
            
            {/* Notification Toast */}
            {notification && (
                <div className="fixed top-5 right-5 glassmorphism p-4 rounded-lg shadow-lg border-2 border-yellow-400 z-50 flex items-center animate-pulse">
                    <IconWarning className="w-6 h-6 mr-3 text-yellow-300"/>
                    <p>{notification}</p>
                </div>
            )}

            {/* Confetti Animation */}
            {showConfetti && (
                <div className="fixed top-0 left-0 w-full h-full pointer-events-none z-50 overflow-hidden">
                    {Array.from({ length: 100 }).map((_, i) => (
                        <div
                            key={i}
                            className="absolute bg-yellow-300 rounded-full"
                            style={{
                                left: `${Math.random() * 100}%`,
                                top: `${-20 + Math.random() * 40}%`,
                                width: `${Math.random() * 10 + 5}px`,
                                height: `${Math.random() * 10 + 5}px`,
                                animation: `fall ${Math.random() * 2 + 3}s linear ${Math.random() * 2}s infinite`,
                                opacity: Math.random() * 0.5 + 0.5,
                            }}
                        ></div>
                    ))}
                    <style>{`
                        @keyframes fall {
                            to {
                                transform: translateY(100vh) rotate(360deg);
                            }
                        }
                    `}</style>
                </div>
            )}
        </>
    );
};

export default App;
