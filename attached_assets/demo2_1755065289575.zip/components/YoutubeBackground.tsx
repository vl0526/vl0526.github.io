import React, { useEffect, useRef } from 'react';
import { YOUTUBE_VIDEO_ID } from '../constants';
import { YTPlayer, YTPlayerEvent } from '../types';

const YoutubeBackground: React.FC = () => {
    const playerRef = useRef<YTPlayer | null>(null);

    useEffect(() => {
        const onPlayerReady = (event: YTPlayerEvent) => {
            event.target.playVideo();
            // Muted by default in playerVars, user must interact to unmute
            event.target.setVolume(20); // Set a low volume
        };

        const unmute = () => {
            const player = playerRef.current;
            if (player && typeof player.unMute === 'function' && player.isMuted()) {
                player.unMute();
            }
        };

        const loadVideo = () => {
            // Do nothing if YT API is not loaded or player is already created
            if (!window.YT || playerRef.current) {
                return;
            }
            playerRef.current = new window.YT.Player('youtube-player', {
                height: '100%',
                width: '100%',
                videoId: YOUTUBE_VIDEO_ID,
                playerVars: {
                    autoplay: 1,
                    controls: 0,
                    loop: 1,
                    playlist: YOUTUBE_VIDEO_ID,
                    mute: 1,
                    playsinline: 1,
                    modestbranding: 1,
                    showinfo: 0,
                    rel: 0,
                },
                events: {
                    onReady: onPlayerReady,
                },
            });
        };

        // If the API is already available, load video immediately.
        // Otherwise, set up the callback and load the script.
        if (window.YT) {
            loadVideo();
        } else {
            const tag = document.createElement('script');
            tag.src = "https://www.youtube.com/iframe_api";
            window.onYouTubeIframeAPIReady = loadVideo;
            const firstScriptTag = document.getElementsByTagName('script')[0];
            if (firstScriptTag?.parentNode) {
                firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
            }
        }
        
        // Add a one-time listener to the body to unmute on first interaction
        document.body.addEventListener('click', unmute, { once: true });

        return () => {
            // Clean up player instance and event listener on component unmount
            playerRef.current?.destroy();
            document.body.removeEventListener('click', unmute);
        };
    }, []);

    return <div id="youtube-player" className="absolute top-0 left-0 w-full h-full" />;
};

export default YoutubeBackground;
