import React, { useState } from 'react';
import { Question } from '../types';
import { IconEdit, IconTrash, IconPlus, IconStars } from './icons';
import { generateQuizQuestionWithGoogleSearch } from '../lib/gemini';

interface AdminPanelProps {
  questions: Question[];
  setQuestions: React.Dispatch<React.SetStateAction<Question[]>>;
  onSendNotification: (message: string) => void;
  onTriggerAnimation: () => void;
}

const QuestionEditor: React.FC<{
  question: Question | null;
  onSave: (q: Question) => void;
  onCancel: () => void;
}> = ({ question, onSave, onCancel }) => {
  const [editedQuestion, setEditedQuestion] = useState<Omit<Question, 'id'>>(() => {
    if (question) {
      return {
        questionText: question.questionText,
        options: [...question.options],
        correctAnswerIndex: question.correctAnswerIndex,
      };
    }
    return {
      questionText: '',
      options: ['', '', '', ''],
      correctAnswerIndex: 0,
    };
  });

  const handleOptionChange = (index: number, value: string) => {
    const newOptions = [...editedQuestion.options];
    newOptions[index] = value;
    setEditedQuestion({ ...editedQuestion, options: newOptions });
  };

  const handleSave = () => {
    onSave({
      id: question?.id || Date.now(),
      ...editedQuestion
    });
  };

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
      <div className="glassmorphism p-6 rounded-lg w-full max-w-2xl border-2 border-purple-400">
        <h3 className="text-2xl font-bold mb-4">{question ? 'Chỉnh sửa câu hỏi' : 'Thêm câu hỏi mới'}</h3>
        <div className="space-y-4">
          <div>
            <label className="block mb-1">Câu hỏi:</label>
            <textarea
              value={editedQuestion.questionText}
              onChange={(e) => setEditedQuestion({ ...editedQuestion, questionText: e.target.value })}
              className="w-full p-2 bg-black/30 rounded"
              rows={3}
            />
          </div>
          <div>
            <label className="block mb-1">Các lựa chọn:</label>
            {editedQuestion.options.map((opt, i) => (
              <input
                key={i}
                type="text"
                value={opt}
                onChange={(e) => handleOptionChange(i, e.target.value)}
                className="w-full p-2 bg-black/30 rounded mb-2"
              />
            ))}
          </div>
          <div>
            <label className="block mb-1">Đáp án đúng (chỉ số 0-3):</label>
            <input
              type="number"
              min="0"
              max="3"
              value={editedQuestion.correctAnswerIndex}
              onChange={(e) => setEditedQuestion({ ...editedQuestion, correctAnswerIndex: parseInt(e.target.value, 10) || 0 })}
              className="w-full p-2 bg-black/30 rounded"
            />
          </div>
        </div>
        <div className="flex justify-end space-x-4 mt-6">
          <button onClick={onCancel} className="bg-gray-600 py-2 px-4 rounded">Hủy</button>
          <button onClick={handleSave} className="bg-purple-600 py-2 px-4 rounded">Lưu</button>
        </div>
      </div>
    </div>
  );
};

const AdminPanel: React.FC<AdminPanelProps> = ({ questions, setQuestions, onSendNotification, onTriggerAnimation }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isEditing, setIsEditing] = useState<Question | null>(null);
  const [notification, setNotification] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const addQuestion = () => {
    setIsEditing({ id: 0, questionText: '', options: ['', '', '', ''], correctAnswerIndex: 0 });
  };

  const editQuestion = (q: Question) => {
    setIsEditing(q);
  };

  const deleteQuestion = (id: number) => {
    if(window.confirm('Bạn có chắc muốn xóa câu hỏi này?')) {
        setQuestions(qs => qs.filter(q => q.id !== id));
    }
  };

  const handleSaveQuestion = (q: Question) => {
    const exists = questions.some(existing => existing.id === q.id);
    if (exists) {
      setQuestions(qs => qs.map(oldQ => (oldQ.id === q.id ? q : oldQ)));
    } else {
      setQuestions(qs => [q, ...qs]);
    }
    setIsEditing(null);
  };
  
  const handleSendNotification = () => {
    if (notification.trim()) {
        onSendNotification(notification);
        setNotification('');
    }
  };

  const handleGenerateQuestion = async () => {
    setIsGenerating(true);
    const newQuestion = await generateQuizQuestionWithGoogleSearch(questions);
    if (newQuestion) {
        setQuestions(prev => [newQuestion, ...prev]);
        onSendNotification('AI đã thêm một câu hỏi mới!');
    } else {
        alert('Không thể tạo câu hỏi mới bằng AI. Vui lòng thử lại.');
    }
    setIsGenerating(false);
  };

  if (!isOpen) {
    return (
      <button onClick={() => setIsOpen(true)} className="fixed bottom-4 right-4 bg-purple-600 text-white p-4 rounded-full shadow-lg hover:bg-purple-700 transition z-40">
        Admin
      </button>
    );
  }

  return (
    <div className="fixed inset-0 lg:inset-auto lg:top-4 lg:right-4 lg:bottom-4 w-full lg:w-96 glassmorphism p-4 rounded-lg shadow-2xl flex flex-col z-40">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-purple-300">Bảng điều khiển Admin</h2>
        <button onClick={() => setIsOpen(false)} className="text-2xl">&times;</button>
      </div>

      <div className="flex-grow overflow-y-auto pr-2">
        <h3 className="font-bold mb-2">Quản lý câu hỏi</h3>
        <div className='space-y-2 mb-4'>
            <button 
                onClick={handleGenerateQuestion} 
                disabled={isGenerating}
                className="w-full flex items-center justify-center bg-teal-500 p-2 rounded hover:bg-teal-600 disabled:bg-gray-500 disabled:cursor-wait transition-colors"
            >
                {isGenerating ? (
                    <>
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Đang tạo bằng AI...
                    </>
                ) : (
                    <>
                        <IconStars className="w-5 h-5 mr-2" />
                        Thêm câu hỏi bằng AI
                    </>
                )}
            </button>
             <button onClick={addQuestion} className="w-full flex items-center justify-center bg-green-600 p-2 rounded hover:bg-green-700">
                <IconPlus className="w-5 h-5 mr-2" /> Thêm thủ công
            </button>
        </div>
       
        <div className="space-y-2">
          {questions.map(q => (
            <div key={q.id} className="bg-black/20 p-2 rounded flex items-center justify-between">
              <p className="truncate flex-1 mr-2">{q.questionText}</p>
              <div className="flex space-x-2">
                <button onClick={() => editQuestion(q)} className="text-blue-400 hover:text-blue-300"><IconEdit className="w-5 h-5" /></button>
                <button onClick={() => deleteQuestion(q.id)} className="text-red-400 hover:text-red-300"><IconTrash className="w-5 h-5" /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="mt-4 pt-4 border-t border-white/20">
          <h3 className="font-bold mb-2">Chức năng Real-time</h3>
          <input 
            type="text"
            value={notification}
            onChange={e => setNotification(e.target.value)}
            placeholder="Nội dung thông báo..."
            className="w-full p-2 bg-black/30 rounded mb-2"
          />
          <button onClick={handleSendNotification} className="w-full bg-blue-600 p-2 rounded mb-2 hover:bg-blue-700">Gửi thông báo</button>
          <button onClick={onTriggerAnimation} className="w-full bg-yellow-600 p-2 rounded hover:bg-yellow-700">Kích hoạt Animation</button>
      </div>

      {isEditing && <QuestionEditor question={isEditing.id === 0 ? null : isEditing} onSave={handleSaveQuestion} onCancel={() => setIsEditing(null)} />}
    </div>
  );
};

export default AdminPanel;