
export const ADMIN_IP = '171.224.181.202';
export const CHEAT_WARNING_LIMIT = 2;
export const YOUTUBE_VIDEO_ID = 'jfKfPfyJRdk'; // Lo-fi hip hop radio
