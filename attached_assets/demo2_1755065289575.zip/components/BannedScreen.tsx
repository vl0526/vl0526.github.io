
import React from 'react';
import { IconSkull } from './icons';

interface BannedScreenProps {
    isAdmin: boolean;
    onUnban: () => void;
}

const BannedScreen: React.FC<BannedScreenProps> = ({ isAdmin, onUnban }) => {
  return (
    <div className="flex flex-col items-center justify-center h-screen p-4 text-center bg-red-900/50">
       <div className="absolute top-0 left-0 w-full h-full bg-black opacity-50"></div>
       <div className="relative z-10 glassmorphism p-8 md:p-12 rounded-2xl border-2 border-red-500/50 shadow-2xl shadow-red-500/20">
        <IconSkull className="w-24 h-24 mx-auto text-red-400 animate-bounce" />
        <h1 className="text-4xl md:text-5xl font-bold mt-4 text-red-400">
          TÀI KHOẢN BỊ KHÓA
        </h1>
        <p className="text-lg md:text-xl text-gray-200 mt-4 max-w-xl">
          Bạn đã bị cấm khỏi bài kiểm tra do vi phạm quy định (rời khỏi trang làm bài quá số lần cho phép).
        </p>
        <p className="text-yellow-300 mt-2 font-bold">
          Chỉ có Quản trị viên mới có thể mở lại tài khoản của bạn.
        </p>
        {isAdmin && (
            <button 
                onClick={onUnban}
                className="mt-8 bg-green-500 text-white font-bold py-3 px-6 rounded-lg hover:bg-green-600 transition-colors"
            >
                [Admin] Mở khóa tài khoản này
            </button>
        )}
      </div>
    </div>
  );
};

export default BannedScreen;
