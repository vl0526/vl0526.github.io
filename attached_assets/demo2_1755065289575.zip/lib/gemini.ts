import { GoogleGenAI } from "@google/genai";
import type { Question } from '../types';

// Assume process.env.API_KEY is configured in the execution environment
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

// Function to clean the response text which might be wrapped in markdown `json ... `
const cleanJsonString = (str: string): string => {
    const match = str.match(/```json\s*([\s\S]*?)\s*```/);
    if (match && match[1]) {
        return match[1].trim();
    }
    return str.trim();
};

export const generateQuizQuestionWithGoogleSearch = async (existingQuestions: Question[]): Promise<Question | null> => {
    const existingQuestionTexts = existingQuestions.map(q => `- ${q.questionText}`).join('\n');
    
    const prompt = `
        Sử dụng công cụ tìm kiếm của Google để tìm và tạo ra MỘT câu hỏi trắc nghiệm 'hack não' hoặc câu đố mẹo mới bằng tiếng Việt.
        Câu hỏi này phải khác biệt hoàn toàn với các câu hỏi trong danh sách sau:
        ${existingQuestionTexts}

        Câu hỏi phải có 4 lựa chọn trả lời, trong đó chỉ có một lựa chọn đúng.
        Hãy cung cấp câu trả lời của bạn ở định dạng JSON. Đối tượng JSON phải có cấu trúc chính xác như sau:
        {
          "questionText": "Nội dung câu hỏi ở đây",
          "options": ["Lựa chọn A", "Lựa chọn B", "Lựa chọn C", "Lựa chọn D"],
          "correctAnswerIndex": 0
        }
        Chỉ số 'correctAnswerIndex' phải là một số từ 0 đến 3, tương ứng với vị trí của đáp án đúng trong mảng 'options'.
        Tuyệt đối không thêm bất kỳ văn bản nào khác ngoài đối tượng JSON trong câu trả lời của bạn.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                tools: [{ googleSearch: {} }],
                temperature: 0.8 // Encourage more creative/varied questions
            },
        });

        const jsonString = cleanJsonString(response.text);
        const newQuestionData = JSON.parse(jsonString);

        // Validate the parsed data structure
        if (
            typeof newQuestionData.questionText === 'string' &&
            newQuestionData.questionText.length > 0 &&
            Array.isArray(newQuestionData.options) &&
            newQuestionData.options.length === 4 &&
            newQuestionData.options.every((opt: any) => typeof opt === 'string' && opt.length > 0) &&
            typeof newQuestionData.correctAnswerIndex === 'number' &&
            newQuestionData.correctAnswerIndex >= 0 &&
            newQuestionData.correctAnswerIndex <= 3
        ) {
            return {
                id: Date.now(),
                questionText: newQuestionData.questionText,
                options: newQuestionData.options,
                correctAnswerIndex: newQuestionData.correctAnswerIndex
            };
        }
        console.error("Generated data from AI has an invalid format:", newQuestionData);
        return null;
    } catch (error) {
        console.error("Error generating question with Gemini:", error);
        return null;
    }
};
