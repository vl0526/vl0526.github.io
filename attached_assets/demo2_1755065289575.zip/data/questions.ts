import { Question } from '../types';

export const initialQuestions: Question[] = [
  {
    id: 1,
    questionText: "Một ly thủy tinh đựng đầy nước, làm thế nào để lấy nước dưới đáy ly mà không đổ nước ra ngoài?",
    options: ["Uống cạn ly", "Lật ngược ly", "Dùng ống hút", "Đập vỡ ly"],
    correctAnswerIndex: 2,
  },
  {
    id: 2,
    questionText: "Bệnh gì mà bác sĩ phải bó tay?",
    options: ["Bệnh nan y", "Bệnh gãy tay", "Bệnh ung thư", "Bệnh tim"],
    correctAnswerIndex: 1,
  },
  {
    id: 3,
    questionText: "Con gì đập thì sống, không đập thì chết?",
    options: ["Con muỗi", "Con ruồi", "Con tim", "Con đò"],
    correctAnswerIndex: 2,
  },
  {
    id: 4,
    questionText: "Ở Việt Nam, con rồng thật sự nằm ở đâu?",
    options: ["Vịnh Hạ Long", "Hoàng thành Thăng Long", "Trên bản đồ", "Dưới sông Cửu Long"],
    correctAnswerIndex: 3,
  },
  {
    id: 5,
    questionText: "Bạn không thể ăn gì cho bữa sáng?",
    options: ["Bữa trưa và bữa tối", "Phở", "Bánh mì", "Trứng"],
    correctAnswerIndex: 0,
  },
  {
    id: 6,
    questionText: "Có một đàn chim đậu trên cành, người thợ săn bắn 'cái rằm'. Hỏi chết mấy con?",
    options: ["0 con", "1 con", "2 con", "15 con (Rằm = 15)"],
    correctAnswerIndex: 3,
  },
  {
    id: 7,
    questionText: "Lịch nào dài nhất thế giới?",
    options: ["Lịch vạn niên", "Lịch sử", "Lịch âm", "Lịch dương"],
    correctAnswerIndex: 1,
  },
  {
    id: 8,
    questionText: "Xã nào là xã có đông dân nhất?",
    options: ["Xã tắc", "Xã hội", "Xã bên cạnh", "Một xã ở Hà Nội"],
    correctAnswerIndex: 1,
  },
  {
    id: 9,
    questionText: "Loại quần nào có diện tích lớn nhất?",
    options: ["Quần bò", "Quần đùi", "Quần đảo", "Quần tây"],
    correctAnswerIndex: 2,
  },
  {
    id: 10,
    questionText: "Cái gì Adam có 2, còn Eva chỉ có 1?",
    options: ["Con mắt", "Cái tay", "Chữ 'A'", "Quả táo"],
    correctAnswerIndex: 2,
  },
  {
    id: 11,
    questionText: "Trong một cuộc thi chạy, nếu bạn vượt qua người cuối cùng, bạn đang ở vị trí nào?",
    options: ["Áp chót", "Cuối cùng", "Thứ hai từ dưới lên", "Vô lý, không thể làm được"],
    correctAnswerIndex: 3,
  },
  {
    id: 12,
    questionText: "Khi Beckham thực hiện quả đá phạt, anh ta sẽ sút vào đâu đầu tiên?",
    options: ["Góc xa", "Góc gần", "Trái banh", "Hàng rào"],
    correctAnswerIndex: 2,
  },
  {
    id: 13,
    questionText: "Sở thú bị cháy, con vật nào chạy ra đầu tiên?",
    options: ["Con sư tử", "Con hổ", "Con người", "Con voi"],
    correctAnswerIndex: 2,
  },
  {
    id: 14,
    questionText: "Cái gì đánh cha, đánh má, đánh anh, chị, em mỗi ngày?",
    options: ["Cái roi", "Cái thước", "Bàn chải đánh răng", "Cái chổi"],
    correctAnswerIndex: 2,
  },
  {
    id: 15,
    questionText: "Làm thế nào để một người bình thường có thể đi trên mặt nước?",
    options: ["Chạy thật nhanh", "Đi trên thuyền", "Đợi nước đóng băng", "Không thể"],
    correctAnswerIndex: 1,
  }
];