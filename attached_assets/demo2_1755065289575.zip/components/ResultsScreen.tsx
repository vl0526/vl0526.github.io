
import React from 'react';
import { Question } from '../types';

interface ResultsScreenProps {
  questions: Question[];
  userAnswers: (number | null)[];
  onRestart: () => void;
}

const ResultsScreen: React.FC<ResultsScreenProps> = ({ questions, userAnswers, onRestart }) => {
  const score = userAnswers.reduce((total, answer, index) => {
    return answer === questions[index].correctAnswerIndex ? total + 1 : total;
  }, 0);

  const percentage = (score / questions.length) * 100;
  
  const getResultMessage = () => {
    if (percentage === 100) return "Thiên tài! Bạn đã hack thành công bộ não của chúng tôi!";
    if (percentage >= 80) return "Xuất sắc! Trí tuệ của bạn thật đáng nể.";
    if (percentage >= 50) return "Không tệ! Bạn có một tư duy sắc bén.";
    if (percentage >= 20) return "Cần cố gắng hơn! Những câu hỏi này không dễ đâu.";
    return "Có vẻ như não bạn đã bị hack. Hãy thử lại!";
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      <div className="w-full max-w-4xl glassmorphism p-8 rounded-2xl shadow-2xl">
        <h1 className="text-4xl font-bold text-center mb-4 neon-text">Kết quả</h1>
        <p className="text-xl text-center text-gray-200 mb-6">{getResultMessage()}</p>
        <div className="text-center mb-8">
          <p className="text-6xl font-bold text-cyan-400">{score} / {questions.length}</p>
          <p className="text-lg">({percentage.toFixed(2)}%)</p>
        </div>

        <div className="max-h-80 overflow-y-auto pr-4 mb-8">
          {questions.map((q, index) => (
            <div key={q.id} className="mb-4 p-4 bg-black/20 rounded-lg">
              <p className="font-bold">{index + 1}. {q.questionText}</p>
              <p className={`mt-2 ${userAnswers[index] === q.correctAnswerIndex ? 'text-green-400' : 'text-red-400'}`}>
                Câu trả lời của bạn: {userAnswers[index] !== null ? q.options[userAnswers[index]!] : 'Chưa trả lời'}
              </p>
              {userAnswers[index] !== q.correctAnswerIndex && (
                <p className="text-yellow-300">Đáp án đúng: {q.options[q.correctAnswerIndex]}</p>
              )}
            </div>
          ))}
        </div>

        <div className="text-center">
          <button
            onClick={onRestart}
            className="bg-cyan-500 text-gray-900 font-bold py-3 px-8 rounded-lg text-xl hover:bg-cyan-400 transform hover:scale-105 transition-all duration-300 ease-in-out neon-border"
          >
            Chơi lại
          </button>
        </div>
      </div>
    </div>
  );
};

export default ResultsScreen;
