export interface Question {
  id: number;
  questionText: string;
  options: string[];
  correctAnswerIndex: number;
}

export enum GameState {
  Welcome,
  Playing,
  Finished,
  Banned
}

// YouTube Player API types
export interface YTPlayer {
    destroy: () => void;
    playVideo: () => void;
    unMute: () => void;
    isMuted: () => boolean;
    setVolume: (volume: number) => void;
}

export interface YTPlayerEvent {
    target: YTPlayer;
}

declare global {
  interface Window {
    onYouTubeIframeAPIReady?: () => void;
    YT?: {
      Player: new (elementId: string, options: {
        height?: string;
        width?: string;
        videoId?: string;
        playerVars?: Record<string, any>;
        events?: {
            onReady?: (event: YTPlayerEvent) => void;
        };
      }) => YTPlayer;
    };
  }
}
