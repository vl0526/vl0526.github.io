// This file is auto-generated.
const puzzles = [
  {
    "question": "Câu 1: 82 + 15 = ?",
    "answer": "97"
  },
  {
    "question": "Câu 2: 95 + 36 = ?",
    "answer": "131"
  },
  {
    "question": "Câu 3: 29 × 18 = ?",
    "answer": "522"
  },
  {
    "question": "Câu 4: 14 × 87 = ?",
    "answer": "1218"
  },
  {
    "question": "Câu 5: 70 × 12 = ?",
    "answer": "840"
  },
  {
    "question": "Câu 6: 55 + 5 = ?",
    "answer": "60"
  },
  {
    "question": "Câu 7: 12 + 28 = ?",
    "answer": "40"
  },
  {
    "question": "Câu 8: 65 + 78 = ?",
    "answer": "143"
  },
  {
    "question": "Câu 9: 72 × 26 = ?",
    "answer": "1872"
  },
  {
    "question": "Câu 10: 84 × 90 = ?",
    "answer": "7560"
  },
  {
    "question": "Câu 11: 54 - 29 = ?",
    "answer": "25"
  },
  {
    "question": "Câu 12: 76 + 36 = ?",
    "answer": "112"
  },
  {
    "question": "Câu 13: 98 × 21 = ?",
    "answer": "2058"
  },
  {
    "question": "Câu 14: 55 - 44 = ?",
    "answer": "11"
  },
  {
    "question": "Câu 15: 28 - 20 = ?",
    "answer": "8"
  },
  {
    "question": "Câu 16: 14 - 12 = ?",
    "answer": "2"
  },
  {
    "question": "Câu 17: 46 - 13 = ?",
    "answer": "33"
  },
  {
    "question": "Câu 18: 78 + 34 = ?",
    "answer": "112"
  },
  {
    "question": "Câu 19: 94 × 59 = ?",
    "answer": "5546"
  },
  {
    "question": "Câu 20: 16 + 49 = ?",
    "answer": "65"
  },
  {
    "question": "Câu 21: 71 × 38 = ?",
    "answer": "2698"
  },
  {
    "question": "Câu 22: 80 × 47 = ?",
    "answer": "3760"
  },
  {
    "question": "Câu 23: 25 + 91 = ?",
    "answer": "116"
  },
  {
    "question": "Câu 24: 6 + 85 = ?",
    "answer": "91"
  },
  {
    "question": "Câu 25: 99 + 38 = ?",
    "answer": "137"
  },
  {
    "question": "Câu 26: 30 - 13 = ?",
    "answer": "17"
  },
  {
    "question": "Câu 27: 36 × 59 = ?",
    "answer": "2124"
  },
  {
    "question": "Câu 28: 47 - 21 = ?",
    "answer": "26"
  },
  {
    "question": "Câu 29: 46 × 27 = ?",
    "answer": "1242"
  },
  {
    "question": "Câu 30: 35 × 90 = ?",
    "answer": "3150"
  },
  {
    "question": "Câu 31: 83 × 10 = ?",
    "answer": "830"
  },
  {
    "question": "Câu 32: 82 × 22 = ?",
    "answer": "1804"
  },
  {
    "question": "Câu 33: 94 + 32 = ?",
    "answer": "126"
  },
  {
    "question": "Câu 34: 60 - 49 = ?",
    "answer": "11"
  },
  {
    "question": "Câu 35: 82 × 89 = ?",
    "answer": "7298"
  },
  {
    "question": "Câu 36: 88 - 29 = ?",
    "answer": "59"
  },
  {
    "question": "Câu 37: 99 + 100 = ?",
    "answer": "199"
  },
  {
    "question": "Câu 38: 30 - 5 = ?",
    "answer": "25"
  },
  {
    "question": "Câu 39: 52 + 35 = ?",
    "answer": "87"
  },
  {
    "question": "Câu 40: 28 × 73 = ?",
    "answer": "2044"
  },
  {
    "question": "Câu 41: 41 × 28 = ?",
    "answer": "1148"
  },
  {
    "question": "Câu 42: 64 × 51 = ?",
    "answer": "3264"
  },
  {
    "question": "Câu 43: 59 - 19 = ?",
    "answer": "40"
  },
  {
    "question": "Câu 44: 18 × 32 = ?",
    "answer": "576"
  },
  {
    "question": "Câu 45: 72 - 69 = ?",
    "answer": "3"
  },
  {
    "question": "Câu 46: 96 - 75 = ?",
    "answer": "21"
  },
  {
    "question": "Câu 47: 75 - 52 = ?",
    "answer": "23"
  },
  {
    "question": "Câu 48: 29 × 18 = ?",
    "answer": "522"
  },
  {
    "question": "Câu 49: 64 + 12 = ?",
    "answer": "76"
  },
  {
    "question": "Câu 50: 15 × 20 = ?",
    "answer": "300"
  },
  {
    "question": "Câu 51: 88 - 21 = ?",
    "answer": "67"
  },
  {
    "question": "Câu 52: 77 - 9 = ?",
    "answer": "68"
  },
  {
    "question": "Câu 53: 77 - 49 = ?",
    "answer": "28"
  },
  {
    "question": "Câu 54: 68 × 33 = ?",
    "answer": "2244"
  },
  {
    "question": "Câu 55: 2 × 88 = ?",
    "answer": "176"
  },
  {
    "question": "Câu 56: 15 × 88 = ?",
    "answer": "1320"
  },
  {
    "question": "Câu 57: 97 × 35 = ?",
    "answer": "3395"
  },
  {
    "question": "Câu 58: 44 - 15 = ?",
    "answer": "29"
  },
  {
    "question": "Câu 59: 56 - 21 = ?",
    "answer": "35"
  },
  {
    "question": "Câu 60: 1 × 93 = ?",
    "answer": "93"
  },
  {
    "question": "Câu 61: 34 + 65 = ?",
    "answer": "99"
  },
  {
    "question": "Câu 62: 65 × 14 = ?",
    "answer": "910"
  },
  {
    "question": "Câu 63: 39 × 82 = ?",
    "answer": "3198"
  },
  {
    "question": "Câu 64: 78 + 26 = ?",
    "answer": "104"
  },
  {
    "question": "Câu 65: 48 + 98 = ?",
    "answer": "146"
  },
  {
    "question": "Câu 66: 70 × 100 = ?",
    "answer": "7000"
  },
  {
    "question": "Câu 67: 77 - 1 = ?",
    "answer": "76"
  },
  {
    "question": "Câu 68: 63 + 3 = ?",
    "answer": "66"
  },
  {
    "question": "Câu 69: 47 + 40 = ?",
    "answer": "87"
  },
  {
    "question": "Câu 70: 8 × 31 = ?",
    "answer": "248"
  },
  {
    "question": "Câu 71: 11 × 11 = ?",
    "answer": "121"
  },
  {
    "question": "Câu 72: 63 × 9 = ?",
    "answer": "567"
  },
  {
    "question": "Câu 73: 99 + 17 = ?",
    "answer": "116"
  },
  {
    "question": "Câu 74: 85 × 61 = ?",
    "answer": "5185"
  },
  {
    "question": "Câu 75: 22 × 34 = ?",
    "answer": "748"
  },
  {
    "question": "Câu 76: 78 + 55 = ?",
    "answer": "133"
  },
  {
    "question": "Câu 77: 70 × 97 = ?",
    "answer": "6790"
  },
  {
    "question": "Câu 78: 89 × 26 = ?",
    "answer": "2314"
  },
  {
    "question": "Câu 79: 40 × 52 = ?",
    "answer": "2080"
  },
  {
    "question": "Câu 80: 84 - 48 = ?",
    "answer": "36"
  },
  {
    "question": "Câu 81: 67 + 58 = ?",
    "answer": "125"
  },
  {
    "question": "Câu 82: 32 + 29 = ?",
    "answer": "61"
  },
  {
    "question": "Câu 83: 44 × 3 = ?",
    "answer": "132"
  },
  {
    "question": "Câu 84: 71 × 30 = ?",
    "answer": "2130"
  },
  {
    "question": "Câu 85: 29 + 1 = ?",
    "answer": "30"
  },
  {
    "question": "Câu 86: 91 + 81 = ?",
    "answer": "172"
  },
  {
    "question": "Câu 87: 30 + 9 = ?",
    "answer": "39"
  },
  {
    "question": "Câu 88: 43 × 10 = ?",
    "answer": "430"
  },
  {
    "question": "Câu 89: 31 × 36 = ?",
    "answer": "1116"
  },
  {
    "question": "Câu 90: 63 × 28 = ?",
    "answer": "1764"
  },
  {
    "question": "Câu 91: 17 × 93 = ?",
    "answer": "1581"
  },
  {
    "question": "Câu 92: 74 + 61 = ?",
    "answer": "135"
  },
  {
    "question": "Câu 93: 61 + 53 = ?",
    "answer": "114"
  },
  {
    "question": "Câu 94: 13 × 13 = ?",
    "answer": "169"
  },
  {
    "question": "Câu 95: 56 - 46 = ?",
    "answer": "10"
  },
  {
    "question": "Câu 96: 53 × 60 = ?",
    "answer": "3180"
  },
  {
    "question": "Câu 97: 7 × 87 = ?",
    "answer": "609"
  },
  {
    "question": "Câu 98: 83 + 13 = ?",
    "answer": "96"
  },
  {
    "question": "Câu 99: 94 - 52 = ?",
    "answer": "42"
  },
  {
    "question": "Câu 100: 14 + 32 = ?",
    "answer": "46"
  },
  {
    "question": "Câu 101: 69 - 25 = ?",
    "answer": "44"
  },
  {
    "question": "Câu 102: 18 + 55 = ?",
    "answer": "73"
  },
  {
    "question": "Câu 103: 36 + 60 = ?",
    "answer": "96"
  },
  {
    "question": "Câu 104: 10 × 57 = ?",
    "answer": "570"
  },
  {
    "question": "Câu 105: 13 × 7 = ?",
    "answer": "91"
  },
  {
    "question": "Câu 106: 70 + 2 = ?",
    "answer": "72"
  },
  {
    "question": "Câu 107: 97 + 31 = ?",
    "answer": "128"
  },
  {
    "question": "Câu 108: 63 - 53 = ?",
    "answer": "10"
  },
  {
    "question": "Câu 109: 28 + 52 = ?",
    "answer": "80"
  },
  {
    "question": "Câu 110: 22 + 49 = ?",
    "answer": "71"
  },
  {
    "question": "Câu 111: 50 - 34 = ?",
    "answer": "16"
  },
  {
    "question": "Câu 112: 37 × 55 = ?",
    "answer": "2035"
  },
  {
    "question": "Câu 113: 94 × 72 = ?",
    "answer": "6768"
  },
  {
    "question": "Câu 114: 92 + 63 = ?",
    "answer": "155"
  },
  {
    "question": "Câu 115: 25 + 38 = ?",
    "answer": "63"
  },
  {
    "question": "Câu 116: 8 × 75 = ?",
    "answer": "600"
  },
  {
    "question": "Câu 117: 70 × 8 = ?",
    "answer": "560"
  },
  {
    "question": "Câu 118: 41 + 8 = ?",
    "answer": "49"
  },
  {
    "question": "Câu 119: 75 × 62 = ?",
    "answer": "4650"
  },
  {
    "question": "Câu 120: 68 + 21 = ?",
    "answer": "89"
  },
  {
    "question": "Câu 121: 66 + 11 = ?",
    "answer": "77"
  },
  {
    "question": "Câu 122: 9 + 77 = ?",
    "answer": "86"
  },
  {
    "question": "Câu 123: 87 - 31 = ?",
    "answer": "56"
  },
  {
    "question": "Câu 124: 16 + 73 = ?",
    "answer": "89"
  },
  {
    "question": "Câu 125: 75 + 77 = ?",
    "answer": "152"
  },
  {
    "question": "Câu 126: 80 - 11 = ?",
    "answer": "69"
  },
  {
    "question": "Câu 127: 85 × 75 = ?",
    "answer": "6375"
  },
  {
    "question": "Câu 128: 67 - 41 = ?",
    "answer": "26"
  },
  {
    "question": "Câu 129: 27 × 86 = ?",
    "answer": "2322"
  },
  {
    "question": "Câu 130: 41 - 31 = ?",
    "answer": "10"
  },
  {
    "question": "Câu 131: 51 × 17 = ?",
    "answer": "867"
  },
  {
    "question": "Câu 132: 83 - 39 = ?",
    "answer": "44"
  },
  {
    "question": "Câu 133: 41 + 97 = ?",
    "answer": "138"
  },
  {
    "question": "Câu 134: 2 × 59 = ?",
    "answer": "118"
  },
  {
    "question": "Câu 135: 73 + 13 = ?",
    "answer": "86"
  },
  {
    "question": "Câu 136: 69 × 28 = ?",
    "answer": "1932"
  },
  {
    "question": "Câu 137: 34 - 17 = ?",
    "answer": "17"
  },
  {
    "question": "Câu 138: 32 - 9 = ?",
    "answer": "23"
  },
  {
    "question": "Câu 139: 37 - 21 = ?",
    "answer": "16"
  },
  {
    "question": "Câu 140: 91 - 70 = ?",
    "answer": "21"
  },
  {
    "question": "Câu 141: 79 × 84 = ?",
    "answer": "6636"
  },
  {
    "question": "Câu 142: 2 × 86 = ?",
    "answer": "172"
  },
  {
    "question": "Câu 143: 39 + 85 = ?",
    "answer": "124"
  },
  {
    "question": "Câu 144: 18 + 34 = ?",
    "answer": "52"
  },
  {
    "question": "Câu 145: 14 × 96 = ?",
    "answer": "1344"
  },
  {
    "question": "Câu 146: 35 - 20 = ?",
    "answer": "15"
  },
  {
    "question": "Câu 147: 78 × 27 = ?",
    "answer": "2106"
  },
  {
    "question": "Câu 148: 44 × 27 = ?",
    "answer": "1188"
  },
  {
    "question": "Câu 149: 82 × 34 = ?",
    "answer": "2788"
  },
  {
    "question": "Câu 150: 63 + 33 = ?",
    "answer": "96"
  },
  {
    "question": "Câu 151: 82 - 12 = ?",
    "answer": "70"
  },
  {
    "question": "Câu 152: 36 + 6 = ?",
    "answer": "42"
  },
  {
    "question": "Câu 153: 43 + 99 = ?",
    "answer": "142"
  },
  {
    "question": "Câu 154: 82 + 34 = ?",
    "answer": "116"
  },
  {
    "question": "Câu 155: 95 × 57 = ?",
    "answer": "5415"
  },
  {
    "question": "Câu 156: 91 × 55 = ?",
    "answer": "5005"
  },
  {
    "question": "Câu 157: 2 + 15 = ?",
    "answer": "17"
  },
  {
    "question": "Câu 158: 89 × 20 = ?",
    "answer": "1780"
  },
  {
    "question": "Câu 159: 5 × 48 = ?",
    "answer": "240"
  },
  {
    "question": "Câu 160: 71 - 19 = ?",
    "answer": "52"
  },
  {
    "question": "Câu 161: 17 - 6 = ?",
    "answer": "11"
  },
  {
    "question": "Câu 162: 47 - 6 = ?",
    "answer": "41"
  },
  {
    "question": "Câu 163: 27 + 88 = ?",
    "answer": "115"
  },
  {
    "question": "Câu 164: 86 - 14 = ?",
    "answer": "72"
  },
  {
    "question": "Câu 165: 100 - 72 = ?",
    "answer": "28"
  },
  {
    "question": "Câu 166: 80 + 96 = ?",
    "answer": "176"
  },
  {
    "question": "Câu 167: 31 + 21 = ?",
    "answer": "52"
  },
  {
    "question": "Câu 168: 53 + 4 = ?",
    "answer": "57"
  },
  {
    "question": "Câu 169: 95 - 43 = ?",
    "answer": "52"
  },
  {
    "question": "Câu 170: 86 + 95 = ?",
    "answer": "181"
  },
  {
    "question": "Câu 171: 35 × 21 = ?",
    "answer": "735"
  },
  {
    "question": "Câu 172: 14 + 49 = ?",
    "answer": "63"
  },
  {
    "question": "Câu 173: 61 + 29 = ?",
    "answer": "90"
  },
  {
    "question": "Câu 174: 59 - 45 = ?",
    "answer": "14"
  },
  {
    "question": "Câu 175: 30 + 29 = ?",
    "answer": "59"
  },
  {
    "question": "Câu 176: 85 - 25 = ?",
    "answer": "60"
  },
  {
    "question": "Câu 177: 43 + 36 = ?",
    "answer": "79"
  },
  {
    "question": "Câu 178: 99 - 36 = ?",
    "answer": "63"
  },
  {
    "question": "Câu 179: 83 - 66 = ?",
    "answer": "17"
  },
  {
    "question": "Câu 180: 87 - 69 = ?",
    "answer": "18"
  },
  {
    "question": "Câu 181: 15 - 4 = ?",
    "answer": "11"
  },
  {
    "question": "Câu 182: 75 - 23 = ?",
    "answer": "52"
  },
  {
    "question": "Câu 183: 5 × 14 = ?",
    "answer": "70"
  },
  {
    "question": "Câu 184: 56 × 45 = ?",
    "answer": "2520"
  },
  {
    "question": "Câu 185: 41 × 56 = ?",
    "answer": "2296"
  },
  {
    "question": "Câu 186: 66 - 15 = ?",
    "answer": "51"
  },
  {
    "question": "Câu 187: 74 - 25 = ?",
    "answer": "49"
  },
  {
    "question": "Câu 188: 91 - 6 = ?",
    "answer": "85"
  },
  {
    "question": "Câu 189: 1 × 67 = ?",
    "answer": "67"
  },
  {
    "question": "Câu 190: 88 × 93 = ?",
    "answer": "8184"
  },
  {
    "question": "Câu 191: 95 + 86 = ?",
    "answer": "181"
  },
  {
    "question": "Câu 192: 47 + 56 = ?",
    "answer": "103"
  },
  {
    "question": "Câu 193: 86 × 43 = ?",
    "answer": "3698"
  },
  {
    "question": "Câu 194: 41 + 85 = ?",
    "answer": "126"
  },
  {
    "question": "Câu 195: 93 × 39 = ?",
    "answer": "3627"
  },
  {
    "question": "Câu 196: 86 - 40 = ?",
    "answer": "46"
  },
  {
    "question": "Câu 197: 42 × 52 = ?",
    "answer": "2184"
  },
  {
    "question": "Câu 198: 38 + 71 = ?",
    "answer": "109"
  },
  {
    "question": "Câu 199: 25 × 54 = ?",
    "answer": "1350"
  },
  {
    "question": "Câu 200: 49 × 87 = ?",
    "answer": "4263"
  },
  {
    "question": "Câu 201: 23 × 79 = ?",
    "answer": "1817"
  },
  {
    "question": "Câu 202: 39 × 52 = ?",
    "answer": "2028"
  },
  {
    "question": "Câu 203: 39 - 1 = ?",
    "answer": "38"
  },
  {
    "question": "Câu 204: 27 × 56 = ?",
    "answer": "1512"
  },
  {
    "question": "Câu 205: 84 - 78 = ?",
    "answer": "6"
  },
  {
    "question": "Câu 206: 60 - 57 = ?",
    "answer": "3"
  },
  {
    "question": "Câu 207: 87 × 28 = ?",
    "answer": "2436"
  },
  {
    "question": "Câu 208: 61 + 95 = ?",
    "answer": "156"
  },
  {
    "question": "Câu 209: 85 - 11 = ?",
    "answer": "74"
  },
  {
    "question": "Câu 210: 66 × 85 = ?",
    "answer": "5610"
  },
  {
    "question": "Câu 211: 80 + 43 = ?",
    "answer": "123"
  },
  {
    "question": "Câu 212: 97 × 31 = ?",
    "answer": "3007"
  },
  {
    "question": "Câu 213: 40 + 29 = ?",
    "answer": "69"
  },
  {
    "question": "Câu 214: 19 + 4 = ?",
    "answer": "23"
  },
  {
    "question": "Câu 215: 32 × 61 = ?",
    "answer": "1952"
  },
  {
    "question": "Câu 216: 99 - 10 = ?",
    "answer": "89"
  },
  {
    "question": "Câu 217: 54 × 81 = ?",
    "answer": "4374"
  },
  {
    "question": "Câu 218: 25 × 92 = ?",
    "answer": "2300"
  },
  {
    "question": "Câu 219: 64 - 50 = ?",
    "answer": "14"
  },
  {
    "question": "Câu 220: 32 × 19 = ?",
    "answer": "608"
  },
  {
    "question": "Câu 221: 89 + 1 = ?",
    "answer": "90"
  },
  {
    "question": "Câu 222: 100 + 55 = ?",
    "answer": "155"
  },
  {
    "question": "Câu 223: 23 × 90 = ?",
    "answer": "2070"
  },
  {
    "question": "Câu 224: 60 × 7 = ?",
    "answer": "420"
  },
  {
    "question": "Câu 225: 32 - 16 = ?",
    "answer": "16"
  },
  {
    "question": "Câu 226: 18 × 60 = ?",
    "answer": "1080"
  },
  {
    "question": "Câu 227: 68 × 72 = ?",
    "answer": "4896"
  },
  {
    "question": "Câu 228: 97 - 41 = ?",
    "answer": "56"
  },
  {
    "question": "Câu 229: 79 × 93 = ?",
    "answer": "7347"
  },
  {
    "question": "Câu 230: 71 - 55 = ?",
    "answer": "16"
  },
  {
    "question": "Câu 231: 96 - 21 = ?",
    "answer": "75"
  },
  {
    "question": "Câu 232: 58 + 34 = ?",
    "answer": "92"
  },
  {
    "question": "Câu 233: 82 × 36 = ?",
    "answer": "2952"
  },
  {
    "question": "Câu 234: 63 + 81 = ?",
    "answer": "144"
  },
  {
    "question": "Câu 235: 36 + 57 = ?",
    "answer": "93"
  },
  {
    "question": "Câu 236: 92 + 37 = ?",
    "answer": "129"
  },
  {
    "question": "Câu 237: 43 - 35 = ?",
    "answer": "8"
  },
  {
    "question": "Câu 238: 70 + 11 = ?",
    "answer": "81"
  },
  {
    "question": "Câu 239: 30 - 20 = ?",
    "answer": "10"
  },
  {
    "question": "Câu 240: 89 × 20 = ?",
    "answer": "1780"
  },
  {
    "question": "Câu 241: 28 - 9 = ?",
    "answer": "19"
  },
  {
    "question": "Câu 242: 53 × 43 = ?",
    "answer": "2279"
  },
  {
    "question": "Câu 243: 60 + 54 = ?",
    "answer": "114"
  },
  {
    "question": "Câu 244: 54 - 27 = ?",
    "answer": "27"
  },
  {
    "question": "Câu 245: 99 × 75 = ?",
    "answer": "7425"
  },
  {
    "question": "Câu 246: 3 × 98 = ?",
    "answer": "294"
  },
  {
    "question": "Câu 247: 49 + 62 = ?",
    "answer": "111"
  },
  {
    "question": "Câu 248: 46 - 39 = ?",
    "answer": "7"
  },
  {
    "question": "Câu 249: 54 × 69 = ?",
    "answer": "3726"
  },
  {
    "question": "Câu 250: 95 × 70 = ?",
    "answer": "6650"
  },
  {
    "question": "Câu 251: 29 + 63 = ?",
    "answer": "92"
  },
  {
    "question": "Câu 252: 56 - 35 = ?",
    "answer": "21"
  },
  {
    "question": "Câu 253: 50 - 4 = ?",
    "answer": "46"
  },
  {
    "question": "Câu 254: 87 - 86 = ?",
    "answer": "1"
  },
  {
    "question": "Câu 255: 93 - 22 = ?",
    "answer": "71"
  },
  {
    "question": "Câu 256: 17 × 80 = ?",
    "answer": "1360"
  },
  {
    "question": "Câu 257: 4 × 51 = ?",
    "answer": "204"
  },
  {
    "question": "Câu 258: 73 + 85 = ?",
    "answer": "158"
  },
  {
    "question": "Câu 259: 83 - 11 = ?",
    "answer": "72"
  },
  {
    "question": "Câu 260: 18 + 60 = ?",
    "answer": "78"
  },
  {
    "question": "Câu 261: 34 - 7 = ?",
    "answer": "27"
  },
  {
    "question": "Câu 262: 42 - 28 = ?",
    "answer": "14"
  },
  {
    "question": "Câu 263: 44 - 42 = ?",
    "answer": "2"
  },
  {
    "question": "Câu 264: 97 - 36 = ?",
    "answer": "61"
  },
  {
    "question": "Câu 265: 33 - 11 = ?",
    "answer": "22"
  },
  {
    "question": "Câu 266: 3 × 96 = ?",
    "answer": "288"
  },
  {
    "question": "Câu 267: 7 + 45 = ?",
    "answer": "52"
  },
  {
    "question": "Câu 268: 84 × 9 = ?",
    "answer": "756"
  },
  {
    "question": "Câu 269: 6 + 97 = ?",
    "answer": "103"
  },
  {
    "question": "Câu 270: 32 + 26 = ?",
    "answer": "58"
  },
  {
    "question": "Câu 271: 80 + 20 = ?",
    "answer": "100"
  },
  {
    "question": "Câu 272: 17 × 61 = ?",
    "answer": "1037"
  },
  {
    "question": "Câu 273: 15 + 73 = ?",
    "answer": "88"
  },
  {
    "question": "Câu 274: 90 - 60 = ?",
    "answer": "30"
  },
  {
    "question": "Câu 275: 99 + 48 = ?",
    "answer": "147"
  },
  {
    "question": "Câu 276: 78 × 78 = ?",
    "answer": "6084"
  },
  {
    "question": "Câu 277: 92 + 15 = ?",
    "answer": "107"
  },
  {
    "question": "Câu 278: 40 × 14 = ?",
    "answer": "560"
  },
  {
    "question": "Câu 279: 4 × 40 = ?",
    "answer": "160"
  },
  {
    "question": "Câu 280: 87 - 49 = ?",
    "answer": "38"
  },
  {
    "question": "Câu 281: 92 + 26 = ?",
    "answer": "118"
  },
  {
    "question": "Câu 282: 76 × 89 = ?",
    "answer": "6764"
  },
  {
    "question": "Câu 283: 32 × 14 = ?",
    "answer": "448"
  },
  {
    "question": "Câu 284: 99 × 39 = ?",
    "answer": "3861"
  },
  {
    "question": "Câu 285: 77 × 16 = ?",
    "answer": "1232"
  },
  {
    "question": "Câu 286: 6 × 45 = ?",
    "answer": "270"
  },
  {
    "question": "Câu 287: 85 - 55 = ?",
    "answer": "30"
  },
  {
    "question": "Câu 288: 9 × 65 = ?",
    "answer": "585"
  },
  {
    "question": "Câu 289: 44 - 2 = ?",
    "answer": "42"
  },
  {
    "question": "Câu 290: 63 - 14 = ?",
    "answer": "49"
  },
  {
    "question": "Câu 291: 82 - 47 = ?",
    "answer": "35"
  },
  {
    "question": "Câu 292: 91 - 20 = ?",
    "answer": "71"
  },
  {
    "question": "Câu 293: 23 × 94 = ?",
    "answer": "2162"
  },
  {
    "question": "Câu 294: 84 × 35 = ?",
    "answer": "2940"
  },
  {
    "question": "Câu 295: 100 - 69 = ?",
    "answer": "31"
  },
  {
    "question": "Câu 296: 60 × 56 = ?",
    "answer": "3360"
  },
  {
    "question": "Câu 297: 76 - 35 = ?",
    "answer": "41"
  },
  {
    "question": "Câu 298: 32 - 12 = ?",
    "answer": "20"
  },
  {
    "question": "Câu 299: 58 - 32 = ?",
    "answer": "26"
  },
  {
    "question": "Câu 300: 73 × 79 = ?",
    "answer": "5767"
  },
  {
    "question": "Câu 301: 49 + 44 = ?",
    "answer": "93"
  },
  {
    "question": "Câu 302: 64 + 42 = ?",
    "answer": "106"
  },
  {
    "question": "Câu 303: 63 - 28 = ?",
    "answer": "35"
  },
  {
    "question": "Câu 304: 44 - 34 = ?",
    "answer": "10"
  },
  {
    "question": "Câu 305: 90 - 77 = ?",
    "answer": "13"
  },
  {
    "question": "Câu 306: 72 × 2 = ?",
    "answer": "144"
  },
  {
    "question": "Câu 307: 25 + 11 = ?",
    "answer": "36"
  },
  {
    "question": "Câu 308: 93 - 53 = ?",
    "answer": "40"
  },
  {
    "question": "Câu 309: 72 + 98 = ?",
    "answer": "170"
  },
  {
    "question": "Câu 310: 89 × 61 = ?",
    "answer": "5429"
  },
  {
    "question": "Câu 311: 92 - 63 = ?",
    "answer": "29"
  },
  {
    "question": "Câu 312: 12 - 3 = ?",
    "answer": "9"
  },
  {
    "question": "Câu 313: 29 × 52 = ?",
    "answer": "1508"
  },
  {
    "question": "Câu 314: 32 × 40 = ?",
    "answer": "1280"
  },
  {
    "question": "Câu 315: 75 - 48 = ?",
    "answer": "27"
  },
  {
    "question": "Câu 316: 71 - 68 = ?",
    "answer": "3"
  },
  {
    "question": "Câu 317: 55 × 96 = ?",
    "answer": "5280"
  },
  {
    "question": "Câu 318: 43 × 46 = ?",
    "answer": "1978"
  },
  {
    "question": "Câu 319: 59 - 35 = ?",
    "answer": "24"
  },
  {
    "question": "Câu 320: 33 + 30 = ?",
    "answer": "63"
  },
  {
    "question": "Câu 321: 93 - 25 = ?",
    "answer": "68"
  },
  {
    "question": "Câu 322: 16 × 96 = ?",
    "answer": "1536"
  },
  {
    "question": "Câu 323: 98 + 89 = ?",
    "answer": "187"
  },
  {
    "question": "Câu 324: 25 × 28 = ?",
    "answer": "700"
  },
  {
    "question": "Câu 325: 62 × 36 = ?",
    "answer": "2232"
  },
  {
    "question": "Câu 326: 76 × 98 = ?",
    "answer": "7448"
  },
  {
    "question": "Câu 327: 77 + 37 = ?",
    "answer": "114"
  },
  {
    "question": "Câu 328: 25 + 38 = ?",
    "answer": "63"
  },
  {
    "question": "Câu 329: 47 - 23 = ?",
    "answer": "24"
  },
  {
    "question": "Câu 330: 2 × 91 = ?",
    "answer": "182"
  },
  {
    "question": "Câu 331: 17 + 36 = ?",
    "answer": "53"
  },
  {
    "question": "Câu 332: 71 - 7 = ?",
    "answer": "64"
  },
  {
    "question": "Câu 333: 90 × 17 = ?",
    "answer": "1530"
  },
  {
    "question": "Câu 334: 97 + 63 = ?",
    "answer": "160"
  },
  {
    "question": "Câu 335: 74 - 2 = ?",
    "answer": "72"
  },
  {
    "question": "Câu 336: 62 - 61 = ?",
    "answer": "1"
  },
  {
    "question": "Câu 337: 44 + 24 = ?",
    "answer": "68"
  },
  {
    "question": "Câu 338: 33 + 62 = ?",
    "answer": "95"
  },
  {
    "question": "Câu 339: 52 - 9 = ?",
    "answer": "43"
  },
  {
    "question": "Câu 340: 10 × 74 = ?",
    "answer": "740"
  },
  {
    "question": "Câu 341: 88 + 7 = ?",
    "answer": "95"
  },
  {
    "question": "Câu 342: 73 - 20 = ?",
    "answer": "53"
  },
  {
    "question": "Câu 343: 11 + 32 = ?",
    "answer": "43"
  },
  {
    "question": "Câu 344: 98 - 72 = ?",
    "answer": "26"
  },
  {
    "question": "Câu 345: 78 × 77 = ?",
    "answer": "6006"
  },
  {
    "question": "Câu 346: 29 × 100 = ?",
    "answer": "2900"
  },
  {
    "question": "Câu 347: 58 - 49 = ?",
    "answer": "9"
  },
  {
    "question": "Câu 348: 76 - 39 = ?",
    "answer": "37"
  },
  {
    "question": "Câu 349: 40 × 73 = ?",
    "answer": "2920"
  },
  {
    "question": "Câu 350: 8 × 79 = ?",
    "answer": "632"
  },
  {
    "question": "Câu 351: 13 + 98 = ?",
    "answer": "111"
  },
  {
    "question": "Câu 352: 81 - 28 = ?",
    "answer": "53"
  },
  {
    "question": "Câu 353: 85 + 11 = ?",
    "answer": "96"
  },
  {
    "question": "Câu 354: 31 × 23 = ?",
    "answer": "713"
  },
  {
    "question": "Câu 355: 10 + 21 = ?",
    "answer": "31"
  },
  {
    "question": "Câu 356: 53 × 58 = ?",
    "answer": "3074"
  },
  {
    "question": "Câu 357: 77 - 61 = ?",
    "answer": "16"
  },
  {
    "question": "Câu 358: 30 - 5 = ?",
    "answer": "25"
  },
  {
    "question": "Câu 359: 91 × 37 = ?",
    "answer": "3367"
  },
  {
    "question": "Câu 360: 59 × 10 = ?",
    "answer": "590"
  },
  {
    "question": "Câu 361: 30 × 34 = ?",
    "answer": "1020"
  },
  {
    "question": "Câu 362: 76 + 85 = ?",
    "answer": "161"
  },
  {
    "question": "Câu 363: 55 × 15 = ?",
    "answer": "825"
  },
  {
    "question": "Câu 364: 29 + 83 = ?",
    "answer": "112"
  },
  {
    "question": "Câu 365: 35 + 19 = ?",
    "answer": "54"
  },
  {
    "question": "Câu 366: 22 - 8 = ?",
    "answer": "14"
  },
  {
    "question": "Câu 367: 77 × 96 = ?",
    "answer": "7392"
  },
  {
    "question": "Câu 368: 37 + 57 = ?",
    "answer": "94"
  },
  {
    "question": "Câu 369: 89 - 60 = ?",
    "answer": "29"
  },
  {
    "question": "Câu 370: 90 - 52 = ?",
    "answer": "38"
  },
  {
    "question": "Câu 371: 70 - 65 = ?",
    "answer": "5"
  },
  {
    "question": "Câu 372: 57 × 11 = ?",
    "answer": "627"
  },
  {
    "question": "Câu 373: 6 × 56 = ?",
    "answer": "336"
  },
  {
    "question": "Câu 374: 78 - 42 = ?",
    "answer": "36"
  },
  {
    "question": "Câu 375: 4 + 12 = ?",
    "answer": "16"
  },
  {
    "question": "Câu 376: 87 × 74 = ?",
    "answer": "6438"
  },
  {
    "question": "Câu 377: 3 × 98 = ?",
    "answer": "294"
  },
  {
    "question": "Câu 378: 35 + 74 = ?",
    "answer": "109"
  },
  {
    "question": "Câu 379: 98 + 97 = ?",
    "answer": "195"
  },
  {
    "question": "Câu 380: 61 × 67 = ?",
    "answer": "4087"
  },
  {
    "question": "Câu 381: 57 + 36 = ?",
    "answer": "93"
  },
  {
    "question": "Câu 382: 75 × 56 = ?",
    "answer": "4200"
  },
  {
    "question": "Câu 383: 63 - 12 = ?",
    "answer": "51"
  },
  {
    "question": "Câu 384: 53 - 45 = ?",
    "answer": "8"
  },
  {
    "question": "Câu 385: 42 + 86 = ?",
    "answer": "128"
  },
  {
    "question": "Câu 386: 43 - 21 = ?",
    "answer": "22"
  },
  {
    "question": "Câu 387: 89 - 64 = ?",
    "answer": "25"
  },
  {
    "question": "Câu 388: 85 × 52 = ?",
    "answer": "4420"
  },
  {
    "question": "Câu 389: 5 + 59 = ?",
    "answer": "64"
  },
  {
    "question": "Câu 390: 41 - 33 = ?",
    "answer": "8"
  },
  {
    "question": "Câu 391: 99 - 15 = ?",
    "answer": "84"
  },
  {
    "question": "Câu 392: 66 × 1 = ?",
    "answer": "66"
  },
  {
    "question": "Câu 393: 70 - 60 = ?",
    "answer": "10"
  },
  {
    "question": "Câu 394: 7 × 25 = ?",
    "answer": "175"
  },
  {
    "question": "Câu 395: 80 - 47 = ?",
    "answer": "33"
  },
  {
    "question": "Câu 396: 81 + 57 = ?",
    "answer": "138"
  },
  {
    "question": "Câu 397: 27 × 35 = ?",
    "answer": "945"
  },
  {
    "question": "Câu 398: 37 - 17 = ?",
    "answer": "20"
  },
  {
    "question": "Câu 399: 90 + 63 = ?",
    "answer": "153"
  },
  {
    "question": "Câu 400: 4 × 81 = ?",
    "answer": "324"
  },
  {
    "question": "Câu 401: 31 + 91 = ?",
    "answer": "122"
  },
  {
    "question": "Câu 402: 40 + 71 = ?",
    "answer": "111"
  },
  {
    "question": "Câu 403: 71 + 53 = ?",
    "answer": "124"
  },
  {
    "question": "Câu 404: 29 - 15 = ?",
    "answer": "14"
  },
  {
    "question": "Câu 405: 16 + 83 = ?",
    "answer": "99"
  },
  {
    "question": "Câu 406: 92 - 64 = ?",
    "answer": "28"
  },
  {
    "question": "Câu 407: 91 - 66 = ?",
    "answer": "25"
  },
  {
    "question": "Câu 408: 62 - 54 = ?",
    "answer": "8"
  },
  {
    "question": "Câu 409: 32 × 59 = ?",
    "answer": "1888"
  },
  {
    "question": "Câu 410: 19 + 50 = ?",
    "answer": "69"
  },
  {
    "question": "Câu 411: 77 × 66 = ?",
    "answer": "5082"
  },
  {
    "question": "Câu 412: 18 - 9 = ?",
    "answer": "9"
  },
  {
    "question": "Câu 413: 99 - 54 = ?",
    "answer": "45"
  },
  {
    "question": "Câu 414: 65 + 35 = ?",
    "answer": "100"
  },
  {
    "question": "Câu 415: 93 - 37 = ?",
    "answer": "56"
  },
  {
    "question": "Câu 416: 76 × 75 = ?",
    "answer": "5700"
  },
  {
    "question": "Câu 417: 63 - 20 = ?",
    "answer": "43"
  },
  {
    "question": "Câu 418: 69 - 62 = ?",
    "answer": "7"
  },
  {
    "question": "Câu 419: 43 × 71 = ?",
    "answer": "3053"
  },
  {
    "question": "Câu 420: 59 - 49 = ?",
    "answer": "10"
  },
  {
    "question": "Câu 421: 25 + 90 = ?",
    "answer": "115"
  },
  {
    "question": "Câu 422: 74 + 50 = ?",
    "answer": "124"
  },
  {
    "question": "Câu 423: 100 + 53 = ?",
    "answer": "153"
  },
  {
    "question": "Câu 424: 96 - 41 = ?",
    "answer": "55"
  },
  {
    "question": "Câu 425: 91 - 49 = ?",
    "answer": "42"
  },
  {
    "question": "Câu 426: 85 + 84 = ?",
    "answer": "169"
  },
  {
    "question": "Câu 427: 64 + 5 = ?",
    "answer": "69"
  },
  {
    "question": "Câu 428: 76 - 65 = ?",
    "answer": "11"
  },
  {
    "question": "Câu 429: 13 + 57 = ?",
    "answer": "70"
  },
  {
    "question": "Câu 430: 68 + 59 = ?",
    "answer": "127"
  },
  {
    "question": "Câu 431: 93 - 19 = ?",
    "answer": "74"
  },
  {
    "question": "Câu 432: 84 + 20 = ?",
    "answer": "104"
  },
  {
    "question": "Câu 433: 61 - 34 = ?",
    "answer": "27"
  },
  {
    "question": "Câu 434: 89 - 80 = ?",
    "answer": "9"
  },
  {
    "question": "Câu 435: 84 - 11 = ?",
    "answer": "73"
  },
  {
    "question": "Câu 436: 87 - 69 = ?",
    "answer": "18"
  },
  {
    "question": "Câu 437: 41 × 81 = ?",
    "answer": "3321"
  },
  {
    "question": "Câu 438: 98 × 63 = ?",
    "answer": "6174"
  },
  {
    "question": "Câu 439: 5 + 80 = ?",
    "answer": "85"
  },
  {
    "question": "Câu 440: 31 × 81 = ?",
    "answer": "2511"
  },
  {
    "question": "Câu 441: 37 × 30 = ?",
    "answer": "1110"
  },
  {
    "question": "Câu 442: 12 + 56 = ?",
    "answer": "68"
  },
  {
    "question": "Câu 443: 98 × 82 = ?",
    "answer": "8036"
  },
  {
    "question": "Câu 444: 13 + 57 = ?",
    "answer": "70"
  },
  {
    "question": "Câu 445: 89 + 39 = ?",
    "answer": "128"
  },
  {
    "question": "Câu 446: 6 + 42 = ?",
    "answer": "48"
  },
  {
    "question": "Câu 447: 46 - 38 = ?",
    "answer": "8"
  },
  {
    "question": "Câu 448: 56 + 19 = ?",
    "answer": "75"
  },
  {
    "question": "Câu 449: 68 × 53 = ?",
    "answer": "3604"
  },
  {
    "question": "Câu 450: 88 + 24 = ?",
    "answer": "112"
  },
  {
    "question": "Câu 451: 23 × 11 = ?",
    "answer": "253"
  },
  {
    "question": "Câu 452: 49 × 80 = ?",
    "answer": "3920"
  },
  {
    "question": "Câu 453: 31 × 64 = ?",
    "answer": "1984"
  },
  {
    "question": "Câu 454: 30 - 19 = ?",
    "answer": "11"
  },
  {
    "question": "Câu 455: 82 - 33 = ?",
    "answer": "49"
  },
  {
    "question": "Câu 456: 33 + 86 = ?",
    "answer": "119"
  },
  {
    "question": "Câu 457: 60 × 37 = ?",
    "answer": "2220"
  },
  {
    "question": "Câu 458: 70 + 21 = ?",
    "answer": "91"
  },
  {
    "question": "Câu 459: 57 × 45 = ?",
    "answer": "2565"
  },
  {
    "question": "Câu 460: 82 - 39 = ?",
    "answer": "43"
  },
  {
    "question": "Câu 461: 89 - 33 = ?",
    "answer": "56"
  },
  {
    "question": "Câu 462: 39 - 26 = ?",
    "answer": "13"
  },
  {
    "question": "Câu 463: 62 + 14 = ?",
    "answer": "76"
  },
  {
    "question": "Câu 464: 74 - 49 = ?",
    "answer": "25"
  },
  {
    "question": "Câu 465: 74 × 38 = ?",
    "answer": "2812"
  },
  {
    "question": "Câu 466: 38 × 3 = ?",
    "answer": "114"
  },
  {
    "question": "Câu 467: 51 + 36 = ?",
    "answer": "87"
  },
  {
    "question": "Câu 468: 73 × 88 = ?",
    "answer": "6424"
  },
  {
    "question": "Câu 469: 7 × 78 = ?",
    "answer": "546"
  },
  {
    "question": "Câu 470: 64 + 37 = ?",
    "answer": "101"
  },
  {
    "question": "Câu 471: 78 + 46 = ?",
    "answer": "124"
  },
  {
    "question": "Câu 472: 82 × 25 = ?",
    "answer": "2050"
  },
  {
    "question": "Câu 473: 33 × 87 = ?",
    "answer": "2871"
  },
  {
    "question": "Câu 474: 99 × 85 = ?",
    "answer": "8415"
  },
  {
    "question": "Câu 475: 18 + 81 = ?",
    "answer": "99"
  },
  {
    "question": "Câu 476: 81 + 83 = ?",
    "answer": "164"
  },
  {
    "question": "Câu 477: 40 + 57 = ?",
    "answer": "97"
  },
  {
    "question": "Câu 478: 75 × 47 = ?",
    "answer": "3525"
  },
  {
    "question": "Câu 479: 17 - 12 = ?",
    "answer": "5"
  },
  {
    "question": "Câu 480: 96 - 42 = ?",
    "answer": "54"
  },
  {
    "question": "Câu 481: 23 + 26 = ?",
    "answer": "49"
  },
  {
    "question": "Câu 482: 70 × 47 = ?",
    "answer": "3290"
  },
  {
    "question": "Câu 483: 65 + 35 = ?",
    "answer": "100"
  },
  {
    "question": "Câu 484: 62 - 33 = ?",
    "answer": "29"
  },
  {
    "question": "Câu 485: 96 + 44 = ?",
    "answer": "140"
  },
  {
    "question": "Câu 486: 60 + 10 = ?",
    "answer": "70"
  },
  {
    "question": "Câu 487: 97 × 29 = ?",
    "answer": "2813"
  },
  {
    "question": "Câu 488: 93 - 87 = ?",
    "answer": "6"
  },
  {
    "question": "Câu 489: 72 + 47 = ?",
    "answer": "119"
  },
  {
    "question": "Câu 490: 51 - 2 = ?",
    "answer": "49"
  },
  {
    "question": "Câu 491: 69 - 16 = ?",
    "answer": "53"
  },
  {
    "question": "Câu 492: 48 × 87 = ?",
    "answer": "4176"
  },
  {
    "question": "Câu 493: 87 × 34 = ?",
    "answer": "2958"
  },
  {
    "question": "Câu 494: 82 - 49 = ?",
    "answer": "33"
  },
  {
    "question": "Câu 495: 14 + 87 = ?",
    "answer": "101"
  },
  {
    "question": "Câu 496: 61 × 4 = ?",
    "answer": "244"
  },
  {
    "question": "Câu 497: 72 × 42 = ?",
    "answer": "3024"
  },
  {
    "question": "Câu 498: 29 + 83 = ?",
    "answer": "112"
  },
  {
    "question": "Câu 499: 82 × 60 = ?",
    "answer": "4920"
  },
  {
    "question": "Câu 500: 84 - 39 = ?",
    "answer": "45"
  },
  {
    "question": "Câu 501: 15 + 18 = ?",
    "answer": "33"
  },
  {
    "question": "Câu 502: 39 - 5 = ?",
    "answer": "34"
  },
  {
    "question": "Câu 503: 15 + 13 = ?",
    "answer": "28"
  },
  {
    "question": "Câu 504: 69 - 18 = ?",
    "answer": "51"
  },
  {
    "question": "Câu 505: 59 × 48 = ?",
    "answer": "2832"
  },
  {
    "question": "Câu 506: 96 × 90 = ?",
    "answer": "8640"
  },
  {
    "question": "Câu 507: 54 × 76 = ?",
    "answer": "4104"
  },
  {
    "question": "Câu 508: 94 - 20 = ?",
    "answer": "74"
  },
  {
    "question": "Câu 509: 84 - 13 = ?",
    "answer": "71"
  },
  {
    "question": "Câu 510: 79 - 53 = ?",
    "answer": "26"
  },
  {
    "question": "Câu 511: 89 - 5 = ?",
    "answer": "84"
  },
  {
    "question": "Câu 512: 57 - 28 = ?",
    "answer": "29"
  },
  {
    "question": "Câu 513: 31 + 47 = ?",
    "answer": "78"
  },
  {
    "question": "Câu 514: 88 × 48 = ?",
    "answer": "4224"
  },
  {
    "question": "Câu 515: 83 + 46 = ?",
    "answer": "129"
  },
  {
    "question": "Câu 516: 51 + 36 = ?",
    "answer": "87"
  },
  {
    "question": "Câu 517: 16 + 59 = ?",
    "answer": "75"
  },
  {
    "question": "Câu 518: 85 × 28 = ?",
    "answer": "2380"
  },
  {
    "question": "Câu 519: 82 + 77 = ?",
    "answer": "159"
  },
  {
    "question": "Câu 520: 7 + 43 = ?",
    "answer": "50"
  },
  {
    "question": "Câu 521: 17 + 73 = ?",
    "answer": "90"
  },
  {
    "question": "Câu 522: 9 × 98 = ?",
    "answer": "882"
  },
  {
    "question": "Câu 523: 27 + 76 = ?",
    "answer": "103"
  },
  {
    "question": "Câu 524: 30 + 43 = ?",
    "answer": "73"
  },
  {
    "question": "Câu 525: 77 - 1 = ?",
    "answer": "76"
  },
  {
    "question": "Câu 526: 19 × 17 = ?",
    "answer": "323"
  },
  {
    "question": "Câu 527: 33 + 23 = ?",
    "answer": "56"
  },
  {
    "question": "Câu 528: 85 + 4 = ?",
    "answer": "89"
  },
  {
    "question": "Câu 529: 2 + 46 = ?",
    "answer": "48"
  },
  {
    "question": "Câu 530: 76 + 42 = ?",
    "answer": "118"
  },
  {
    "question": "Câu 531: 23 + 34 = ?",
    "answer": "57"
  },
  {
    "question": "Câu 532: 95 - 17 = ?",
    "answer": "78"
  },
  {
    "question": "Câu 533: 68 × 15 = ?",
    "answer": "1020"
  },
  {
    "question": "Câu 534: 61 - 9 = ?",
    "answer": "52"
  },
  {
    "question": "Câu 535: 100 × 47 = ?",
    "answer": "4700"
  },
  {
    "question": "Câu 536: 76 - 14 = ?",
    "answer": "62"
  },
  {
    "question": "Câu 537: 65 × 29 = ?",
    "answer": "1885"
  },
  {
    "question": "Câu 538: 6 × 94 = ?",
    "answer": "564"
  },
  {
    "question": "Câu 539: 67 - 39 = ?",
    "answer": "28"
  },
  {
    "question": "Câu 540: 83 + 4 = ?",
    "answer": "87"
  },
  {
    "question": "Câu 541: 62 - 52 = ?",
    "answer": "10"
  },
  {
    "question": "Câu 542: 88 - 14 = ?",
    "answer": "74"
  },
  {
    "question": "Câu 543: 92 + 57 = ?",
    "answer": "149"
  },
  {
    "question": "Câu 544: 11 × 42 = ?",
    "answer": "462"
  },
  {
    "question": "Câu 545: 19 + 9 = ?",
    "answer": "28"
  },
  {
    "question": "Câu 546: 36 × 80 = ?",
    "answer": "2880"
  },
  {
    "question": "Câu 547: 75 × 71 = ?",
    "answer": "5325"
  },
  {
    "question": "Câu 548: 42 × 49 = ?",
    "answer": "2058"
  },
  {
    "question": "Câu 549: 68 - 38 = ?",
    "answer": "30"
  },
  {
    "question": "Câu 550: 78 - 65 = ?",
    "answer": "13"
  },
  {
    "question": "Câu 551: 13 + 90 = ?",
    "answer": "103"
  },
  {
    "question": "Câu 552: 84 × 84 = ?",
    "answer": "7056"
  },
  {
    "question": "Câu 553: 93 - 28 = ?",
    "answer": "65"
  },
  {
    "question": "Câu 554: 58 - 30 = ?",
    "answer": "28"
  },
  {
    "question": "Câu 555: 59 - 44 = ?",
    "answer": "15"
  },
  {
    "question": "Câu 556: 54 + 94 = ?",
    "answer": "148"
  },
  {
    "question": "Câu 557: 55 - 41 = ?",
    "answer": "14"
  },
  {
    "question": "Câu 558: 86 - 33 = ?",
    "answer": "53"
  },
  {
    "question": "Câu 559: 88 - 20 = ?",
    "answer": "68"
  },
  {
    "question": "Câu 560: 9 + 12 = ?",
    "answer": "21"
  },
  {
    "question": "Câu 561: 12 + 56 = ?",
    "answer": "68"
  },
  {
    "question": "Câu 562: 96 - 95 = ?",
    "answer": "1"
  },
  {
    "question": "Câu 563: 17 + 72 = ?",
    "answer": "89"
  },
  {
    "question": "Câu 564: 76 × 72 = ?",
    "answer": "5472"
  },
  {
    "question": "Câu 565: 43 + 86 = ?",
    "answer": "129"
  },
  {
    "question": "Câu 566: 53 × 46 = ?",
    "answer": "2438"
  },
  {
    "question": "Câu 567: 97 × 55 = ?",
    "answer": "5335"
  },
  {
    "question": "Câu 568: 7 × 37 = ?",
    "answer": "259"
  },
  {
    "question": "Câu 569: 40 + 46 = ?",
    "answer": "86"
  },
  {
    "question": "Câu 570: 74 + 65 = ?",
    "answer": "139"
  },
  {
    "question": "Câu 571: 85 - 20 = ?",
    "answer": "65"
  },
  {
    "question": "Câu 572: 29 - 14 = ?",
    "answer": "15"
  },
  {
    "question": "Câu 573: 72 + 48 = ?",
    "answer": "120"
  },
  {
    "question": "Câu 574: 98 × 36 = ?",
    "answer": "3528"
  },
  {
    "question": "Câu 575: 29 × 55 = ?",
    "answer": "1595"
  },
  {
    "question": "Câu 576: 99 × 80 = ?",
    "answer": "7920"
  },
  {
    "question": "Câu 577: 87 × 83 = ?",
    "answer": "7221"
  },
  {
    "question": "Câu 578: 4 × 78 = ?",
    "answer": "312"
  },
  {
    "question": "Câu 579: 89 + 35 = ?",
    "answer": "124"
  },
  {
    "question": "Câu 580: 24 × 35 = ?",
    "answer": "840"
  },
  {
    "question": "Câu 581: 98 - 40 = ?",
    "answer": "58"
  },
  {
    "question": "Câu 582: 45 + 1 = ?",
    "answer": "46"
  },
  {
    "question": "Câu 583: 19 × 73 = ?",
    "answer": "1387"
  },
  {
    "question": "Câu 584: 52 + 9 = ?",
    "answer": "61"
  },
  {
    "question": "Câu 585: 95 + 82 = ?",
    "answer": "177"
  },
  {
    "question": "Câu 586: 12 × 96 = ?",
    "answer": "1152"
  },
  {
    "question": "Câu 587: 49 - 28 = ?",
    "answer": "21"
  },
  {
    "question": "Câu 588: 59 + 44 = ?",
    "answer": "103"
  },
  {
    "question": "Câu 589: 48 × 40 = ?",
    "answer": "1920"
  },
  {
    "question": "Câu 590: 42 × 100 = ?",
    "answer": "4200"
  },
  {
    "question": "Câu 591: 77 + 11 = ?",
    "answer": "88"
  },
  {
    "question": "Câu 592: 20 × 21 = ?",
    "answer": "420"
  },
  {
    "question": "Câu 593: 7 + 87 = ?",
    "answer": "94"
  },
  {
    "question": "Câu 594: 35 × 57 = ?",
    "answer": "1995"
  },
  {
    "question": "Câu 595: 55 × 63 = ?",
    "answer": "3465"
  },
  {
    "question": "Câu 596: 57 - 54 = ?",
    "answer": "3"
  },
  {
    "question": "Câu 597: 28 × 97 = ?",
    "answer": "2716"
  },
  {
    "question": "Câu 598: 45 - 15 = ?",
    "answer": "30"
  },
  {
    "question": "Câu 599: 15 × 37 = ?",
    "answer": "555"
  },
  {
    "question": "Câu 600: 87 - 76 = ?",
    "answer": "11"
  },
  {
    "question": "Câu 601: 86 - 68 = ?",
    "answer": "18"
  },
  {
    "question": "Câu 602: 29 - 6 = ?",
    "answer": "23"
  },
  {
    "question": "Câu 603: 77 + 8 = ?",
    "answer": "85"
  },
  {
    "question": "Câu 604: 27 + 39 = ?",
    "answer": "66"
  },
  {
    "question": "Câu 605: 99 - 18 = ?",
    "answer": "81"
  },
  {
    "question": "Câu 606: 38 + 42 = ?",
    "answer": "80"
  },
  {
    "question": "Câu 607: 1 × 64 = ?",
    "answer": "64"
  },
  {
    "question": "Câu 608: 56 + 23 = ?",
    "answer": "79"
  },
  {
    "question": "Câu 609: 49 × 69 = ?",
    "answer": "3381"
  },
  {
    "question": "Câu 610: 30 × 65 = ?",
    "answer": "1950"
  },
  {
    "question": "Câu 611: 86 + 46 = ?",
    "answer": "132"
  },
  {
    "question": "Câu 612: 51 + 95 = ?",
    "answer": "146"
  },
  {
    "question": "Câu 613: 56 - 3 = ?",
    "answer": "53"
  },
  {
    "question": "Câu 614: 10 × 41 = ?",
    "answer": "410"
  },
  {
    "question": "Câu 615: 74 - 55 = ?",
    "answer": "19"
  },
  {
    "question": "Câu 616: 91 - 82 = ?",
    "answer": "9"
  },
  {
    "question": "Câu 617: 38 - 15 = ?",
    "answer": "23"
  },
  {
    "question": "Câu 618: 3 + 42 = ?",
    "answer": "45"
  },
  {
    "question": "Câu 619: 80 × 59 = ?",
    "answer": "4720"
  },
  {
    "question": "Câu 620: 47 - 12 = ?",
    "answer": "35"
  },
  {
    "question": "Câu 621: 32 - 14 = ?",
    "answer": "18"
  },
  {
    "question": "Câu 622: 76 × 52 = ?",
    "answer": "3952"
  },
  {
    "question": "Câu 623: 51 - 11 = ?",
    "answer": "40"
  },
  {
    "question": "Câu 624: 96 + 44 = ?",
    "answer": "140"
  },
  {
    "question": "Câu 625: 43 + 100 = ?",
    "answer": "143"
  },
  {
    "question": "Câu 626: 10 × 66 = ?",
    "answer": "660"
  },
  {
    "question": "Câu 627: 15 × 68 = ?",
    "answer": "1020"
  },
  {
    "question": "Câu 628: 100 - 25 = ?",
    "answer": "75"
  },
  {
    "question": "Câu 629: 45 × 94 = ?",
    "answer": "4230"
  },
  {
    "question": "Câu 630: 19 + 31 = ?",
    "answer": "50"
  },
  {
    "question": "Câu 631: 19 + 33 = ?",
    "answer": "52"
  },
  {
    "question": "Câu 632: 23 + 78 = ?",
    "answer": "101"
  },
  {
    "question": "Câu 633: 98 × 98 = ?",
    "answer": "9604"
  },
  {
    "question": "Câu 634: 10 × 23 = ?",
    "answer": "230"
  },
  {
    "question": "Câu 635: 64 × 60 = ?",
    "answer": "3840"
  },
  {
    "question": "Câu 636: 98 - 75 = ?",
    "answer": "23"
  },
  {
    "question": "Câu 637: 88 × 73 = ?",
    "answer": "6424"
  },
  {
    "question": "Câu 638: 82 - 80 = ?",
    "answer": "2"
  },
  {
    "question": "Câu 639: 81 + 41 = ?",
    "answer": "122"
  },
  {
    "question": "Câu 640: 57 - 9 = ?",
    "answer": "48"
  },
  {
    "question": "Câu 641: 81 - 57 = ?",
    "answer": "24"
  },
  {
    "question": "Câu 642: 36 + 76 = ?",
    "answer": "112"
  },
  {
    "question": "Câu 643: 46 + 65 = ?",
    "answer": "111"
  },
  {
    "question": "Câu 644: 60 - 40 = ?",
    "answer": "20"
  },
  {
    "question": "Câu 645: 8 - 5 = ?",
    "answer": "3"
  },
  {
    "question": "Câu 646: 37 × 10 = ?",
    "answer": "370"
  },
  {
    "question": "Câu 647: 12 × 79 = ?",
    "answer": "948"
  },
  {
    "question": "Câu 648: 65 - 50 = ?",
    "answer": "15"
  },
  {
    "question": "Câu 649: 75 × 71 = ?",
    "answer": "5325"
  },
  {
    "question": "Câu 650: 6 × 58 = ?",
    "answer": "348"
  },
  {
    "question": "Câu 651: 84 - 25 = ?",
    "answer": "59"
  },
  {
    "question": "Câu 652: 78 × 61 = ?",
    "answer": "4758"
  },
  {
    "question": "Câu 653: 20 - 8 = ?",
    "answer": "12"
  },
  {
    "question": "Câu 654: 14 × 44 = ?",
    "answer": "616"
  },
  {
    "question": "Câu 655: 11 × 65 = ?",
    "answer": "715"
  },
  {
    "question": "Câu 656: 23 + 6 = ?",
    "answer": "29"
  },
  {
    "question": "Câu 657: 91 - 57 = ?",
    "answer": "34"
  },
  {
    "question": "Câu 658: 68 × 67 = ?",
    "answer": "4556"
  },
  {
    "question": "Câu 659: 47 - 21 = ?",
    "answer": "26"
  },
  {
    "question": "Câu 660: 50 - 37 = ?",
    "answer": "13"
  },
  {
    "question": "Câu 661: 100 × 44 = ?",
    "answer": "4400"
  },
  {
    "question": "Câu 662: 77 × 7 = ?",
    "answer": "539"
  },
  {
    "question": "Câu 663: 83 + 43 = ?",
    "answer": "126"
  },
  {
    "question": "Câu 664: 43 × 13 = ?",
    "answer": "559"
  },
  {
    "question": "Câu 665: 87 - 50 = ?",
    "answer": "37"
  },
  {
    "question": "Câu 666: 33 × 93 = ?",
    "answer": "3069"
  },
  {
    "question": "Câu 667: 78 - 20 = ?",
    "answer": "58"
  },
  {
    "question": "Câu 668: 11 × 75 = ?",
    "answer": "825"
  },
  {
    "question": "Câu 669: 45 - 19 = ?",
    "answer": "26"
  },
  {
    "question": "Câu 670: 84 × 90 = ?",
    "answer": "7560"
  },
  {
    "question": "Câu 671: 51 × 17 = ?",
    "answer": "867"
  },
  {
    "question": "Câu 672: 91 - 11 = ?",
    "answer": "80"
  },
  {
    "question": "Câu 673: 72 × 49 = ?",
    "answer": "3528"
  },
  {
    "question": "Câu 674: 43 × 17 = ?",
    "answer": "731"
  },
  {
    "question": "Câu 675: 90 × 95 = ?",
    "answer": "8550"
  },
  {
    "question": "Câu 676: 68 × 12 = ?",
    "answer": "816"
  },
  {
    "question": "Câu 677: 86 × 55 = ?",
    "answer": "4730"
  },
  {
    "question": "Câu 678: 47 - 3 = ?",
    "answer": "44"
  },
  {
    "question": "Câu 679: 40 + 24 = ?",
    "answer": "64"
  },
  {
    "question": "Câu 680: 99 - 44 = ?",
    "answer": "55"
  },
  {
    "question": "Câu 681: 25 + 29 = ?",
    "answer": "54"
  },
  {
    "question": "Câu 682: 20 - 10 = ?",
    "answer": "10"
  },
  {
    "question": "Câu 683: 13 × 65 = ?",
    "answer": "845"
  },
  {
    "question": "Câu 684: 95 + 68 = ?",
    "answer": "163"
  },
  {
    "question": "Câu 685: 85 × 44 = ?",
    "answer": "3740"
  },
  {
    "question": "Câu 686: 77 - 17 = ?",
    "answer": "60"
  },
  {
    "question": "Câu 687: 20 + 21 = ?",
    "answer": "41"
  },
  {
    "question": "Câu 688: 89 × 99 = ?",
    "answer": "8811"
  },
  {
    "question": "Câu 689: 93 - 22 = ?",
    "answer": "71"
  },
  {
    "question": "Câu 690: 53 - 6 = ?",
    "answer": "47"
  },
  {
    "question": "Câu 691: 87 + 93 = ?",
    "answer": "180"
  },
  {
    "question": "Câu 692: 79 - 57 = ?",
    "answer": "22"
  },
  {
    "question": "Câu 693: 97 - 96 = ?",
    "answer": "1"
  },
  {
    "question": "Câu 694: 30 + 69 = ?",
    "answer": "99"
  },
  {
    "question": "Câu 695: 40 + 61 = ?",
    "answer": "101"
  },
  {
    "question": "Câu 696: 48 × 87 = ?",
    "answer": "4176"
  },
  {
    "question": "Câu 697: 60 - 57 = ?",
    "answer": "3"
  },
  {
    "question": "Câu 698: 100 × 49 = ?",
    "answer": "4900"
  },
  {
    "question": "Câu 699: 68 + 54 = ?",
    "answer": "122"
  },
  {
    "question": "Câu 700: 26 + 78 = ?",
    "answer": "104"
  },
  {
    "question": "Câu 701: 33 × 7 = ?",
    "answer": "231"
  },
  {
    "question": "Câu 702: 62 × 48 = ?",
    "answer": "2976"
  },
  {
    "question": "Câu 703: 14 × 92 = ?",
    "answer": "1288"
  },
  {
    "question": "Câu 704: 16 + 37 = ?",
    "answer": "53"
  },
  {
    "question": "Câu 705: 98 - 21 = ?",
    "answer": "77"
  },
  {
    "question": "Câu 706: 58 + 66 = ?",
    "answer": "124"
  },
  {
    "question": "Câu 707: 56 + 12 = ?",
    "answer": "68"
  },
  {
    "question": "Câu 708: 58 + 45 = ?",
    "answer": "103"
  },
  {
    "question": "Câu 709: 54 - 7 = ?",
    "answer": "47"
  },
  {
    "question": "Câu 710: 65 + 48 = ?",
    "answer": "113"
  },
  {
    "question": "Câu 711: 50 - 11 = ?",
    "answer": "39"
  },
  {
    "question": "Câu 712: 29 - 4 = ?",
    "answer": "25"
  },
  {
    "question": "Câu 713: 13 × 92 = ?",
    "answer": "1196"
  },
  {
    "question": "Câu 714: 43 + 19 = ?",
    "answer": "62"
  },
  {
    "question": "Câu 715: 37 - 5 = ?",
    "answer": "32"
  },
  {
    "question": "Câu 716: 90 × 18 = ?",
    "answer": "1620"
  },
  {
    "question": "Câu 717: 61 × 58 = ?",
    "answer": "3538"
  },
  {
    "question": "Câu 718: 1 + 11 = ?",
    "answer": "12"
  },
  {
    "question": "Câu 719: 33 + 28 = ?",
    "answer": "61"
  },
  {
    "question": "Câu 720: 71 × 94 = ?",
    "answer": "6674"
  },
  {
    "question": "Câu 721: 68 + 55 = ?",
    "answer": "123"
  },
  {
    "question": "Câu 722: 100 + 37 = ?",
    "answer": "137"
  },
  {
    "question": "Câu 723: 39 + 16 = ?",
    "answer": "55"
  },
  {
    "question": "Câu 724: 31 × 54 = ?",
    "answer": "1674"
  },
  {
    "question": "Câu 725: 80 + 59 = ?",
    "answer": "139"
  },
  {
    "question": "Câu 726: 15 × 64 = ?",
    "answer": "960"
  },
  {
    "question": "Câu 727: 69 × 3 = ?",
    "answer": "207"
  },
  {
    "question": "Câu 728: 66 + 74 = ?",
    "answer": "140"
  },
  {
    "question": "Câu 729: 92 - 19 = ?",
    "answer": "73"
  },
  {
    "question": "Câu 730: 55 × 1 = ?",
    "answer": "55"
  },
  {
    "question": "Câu 731: 46 × 31 = ?",
    "answer": "1426"
  },
  {
    "question": "Câu 732: 54 × 24 = ?",
    "answer": "1296"
  },
  {
    "question": "Câu 733: 86 × 11 = ?",
    "answer": "946"
  },
  {
    "question": "Câu 734: 47 × 9 = ?",
    "answer": "423"
  },
  {
    "question": "Câu 735: 70 × 65 = ?",
    "answer": "4550"
  },
  {
    "question": "Câu 736: 71 - 3 = ?",
    "answer": "68"
  },
  {
    "question": "Câu 737: 61 × 6 = ?",
    "answer": "366"
  },
  {
    "question": "Câu 738: 50 - 48 = ?",
    "answer": "2"
  },
  {
    "question": "Câu 739: 96 - 3 = ?",
    "answer": "93"
  },
  {
    "question": "Câu 740: 9 + 45 = ?",
    "answer": "54"
  },
  {
    "question": "Câu 741: 94 × 85 = ?",
    "answer": "7990"
  },
  {
    "question": "Câu 742: 14 × 99 = ?",
    "answer": "1386"
  },
  {
    "question": "Câu 743: 97 - 95 = ?",
    "answer": "2"
  },
  {
    "question": "Câu 744: 18 - 6 = ?",
    "answer": "12"
  },
  {
    "question": "Câu 745: 70 × 44 = ?",
    "answer": "3080"
  },
  {
    "question": "Câu 746: 23 × 100 = ?",
    "answer": "2300"
  },
  {
    "question": "Câu 747: 90 - 60 = ?",
    "answer": "30"
  },
  {
    "question": "Câu 748: 81 + 24 = ?",
    "answer": "105"
  },
  {
    "question": "Câu 749: 92 - 9 = ?",
    "answer": "83"
  },
  {
    "question": "Câu 750: 5 + 38 = ?",
    "answer": "43"
  },
  {
    "question": "Câu 751: 6 + 26 = ?",
    "answer": "32"
  },
  {
    "question": "Câu 752: 41 × 40 = ?",
    "answer": "1640"
  },
  {
    "question": "Câu 753: 70 - 51 = ?",
    "answer": "19"
  },
  {
    "question": "Câu 754: 33 × 5 = ?",
    "answer": "165"
  },
  {
    "question": "Câu 755: 37 - 25 = ?",
    "answer": "12"
  },
  {
    "question": "Câu 756: 100 × 7 = ?",
    "answer": "700"
  },
  {
    "question": "Câu 757: 43 + 35 = ?",
    "answer": "78"
  },
  {
    "question": "Câu 758: 56 - 48 = ?",
    "answer": "8"
  },
  {
    "question": "Câu 759: 96 - 57 = ?",
    "answer": "39"
  },
  {
    "question": "Câu 760: 44 - 24 = ?",
    "answer": "20"
  },
  {
    "question": "Câu 761: 89 - 64 = ?",
    "answer": "25"
  },
  {
    "question": "Câu 762: 67 + 35 = ?",
    "answer": "102"
  },
  {
    "question": "Câu 763: 94 + 55 = ?",
    "answer": "149"
  },
  {
    "question": "Câu 764: 56 + 78 = ?",
    "answer": "134"
  },
  {
    "question": "Câu 765: 70 - 38 = ?",
    "answer": "32"
  },
  {
    "question": "Câu 766: 14 - 11 = ?",
    "answer": "3"
  },
  {
    "question": "Câu 767: 85 - 38 = ?",
    "answer": "47"
  },
  {
    "question": "Câu 768: 58 × 78 = ?",
    "answer": "4524"
  },
  {
    "question": "Câu 769: 55 × 22 = ?",
    "answer": "1210"
  },
  {
    "question": "Câu 770: 57 - 45 = ?",
    "answer": "12"
  },
  {
    "question": "Câu 771: 94 - 6 = ?",
    "answer": "88"
  },
  {
    "question": "Câu 772: 79 - 56 = ?",
    "answer": "23"
  },
  {
    "question": "Câu 773: 82 + 8 = ?",
    "answer": "90"
  },
  {
    "question": "Câu 774: 86 - 82 = ?",
    "answer": "4"
  },
  {
    "question": "Câu 775: 47 × 66 = ?",
    "answer": "3102"
  },
  {
    "question": "Câu 776: 87 + 21 = ?",
    "answer": "108"
  },
  {
    "question": "Câu 777: 19 × 78 = ?",
    "answer": "1482"
  },
  {
    "question": "Câu 778: 57 + 5 = ?",
    "answer": "62"
  },
  {
    "question": "Câu 779: 9 × 31 = ?",
    "answer": "279"
  },
  {
    "question": "Câu 780: 47 - 47 = ?",
    "answer": "0"
  },
  {
    "question": "Câu 781: 73 × 5 = ?",
    "answer": "365"
  },
  {
    "question": "Câu 782: 87 - 20 = ?",
    "answer": "67"
  },
  {
    "question": "Câu 783: 48 - 48 = ?",
    "answer": "0"
  },
  {
    "question": "Câu 784: 98 × 10 = ?",
    "answer": "980"
  },
  {
    "question": "Câu 785: 68 - 18 = ?",
    "answer": "50"
  },
  {
    "question": "Câu 786: 51 × 41 = ?",
    "answer": "2091"
  },
  {
    "question": "Câu 787: 36 + 32 = ?",
    "answer": "68"
  },
  {
    "question": "Câu 788: 4 + 95 = ?",
    "answer": "99"
  },
  {
    "question": "Câu 789: 67 - 64 = ?",
    "answer": "3"
  },
  {
    "question": "Câu 790: 72 - 16 = ?",
    "answer": "56"
  },
  {
    "question": "Câu 791: 100 × 34 = ?",
    "answer": "3400"
  },
  {
    "question": "Câu 792: 58 × 28 = ?",
    "answer": "1624"
  },
  {
    "question": "Câu 793: 89 - 37 = ?",
    "answer": "52"
  },
  {
    "question": "Câu 794: 26 + 16 = ?",
    "answer": "42"
  },
  {
    "question": "Câu 795: 10 + 58 = ?",
    "answer": "68"
  },
  {
    "question": "Câu 796: 92 + 57 = ?",
    "answer": "149"
  },
  {
    "question": "Câu 797: 88 × 41 = ?",
    "answer": "3608"
  },
  {
    "question": "Câu 798: 45 + 91 = ?",
    "answer": "136"
  },
  {
    "question": "Câu 799: 71 - 70 = ?",
    "answer": "1"
  },
  {
    "question": "Câu 800: 39 × 21 = ?",
    "answer": "819"
  },
  {
    "question": "Câu 801: 91 × 90 = ?",
    "answer": "8190"
  },
  {
    "question": "Câu 802: 23 × 47 = ?",
    "answer": "1081"
  },
  {
    "question": "Câu 803: 29 + 16 = ?",
    "answer": "45"
  },
  {
    "question": "Câu 804: 31 - 18 = ?",
    "answer": "13"
  },
  {
    "question": "Câu 805: 4 × 47 = ?",
    "answer": "188"
  },
  {
    "question": "Câu 806: 74 - 48 = ?",
    "answer": "26"
  },
  {
    "question": "Câu 807: 71 × 17 = ?",
    "answer": "1207"
  },
  {
    "question": "Câu 808: 12 - 9 = ?",
    "answer": "3"
  },
  {
    "question": "Câu 809: 51 × 92 = ?",
    "answer": "4692"
  },
  {
    "question": "Câu 810: 68 - 62 = ?",
    "answer": "6"
  },
  {
    "question": "Câu 811: 99 × 53 = ?",
    "answer": "5247"
  },
  {
    "question": "Câu 812: 17 - 10 = ?",
    "answer": "7"
  },
  {
    "question": "Câu 813: 83 - 10 = ?",
    "answer": "73"
  },
  {
    "question": "Câu 814: 60 × 88 = ?",
    "answer": "5280"
  },
  {
    "question": "Câu 815: 45 × 17 = ?",
    "answer": "765"
  },
  {
    "question": "Câu 816: 82 + 76 = ?",
    "answer": "158"
  },
  {
    "question": "Câu 817: 99 - 17 = ?",
    "answer": "82"
  },
  {
    "question": "Câu 818: 65 + 8 = ?",
    "answer": "73"
  },
  {
    "question": "Câu 819: 67 - 20 = ?",
    "answer": "47"
  },
  {
    "question": "Câu 820: 22 - 21 = ?",
    "answer": "1"
  },
  {
    "question": "Câu 821: 91 - 29 = ?",
    "answer": "62"
  },
  {
    "question": "Câu 822: 67 + 37 = ?",
    "answer": "104"
  },
  {
    "question": "Câu 823: 33 × 26 = ?",
    "answer": "858"
  },
  {
    "question": "Câu 824: 71 + 36 = ?",
    "answer": "107"
  },
  {
    "question": "Câu 825: 81 × 39 = ?",
    "answer": "3159"
  },
  {
    "question": "Câu 826: 69 × 12 = ?",
    "answer": "828"
  },
  {
    "question": "Câu 827: 83 × 22 = ?",
    "answer": "1826"
  },
  {
    "question": "Câu 828: 75 + 20 = ?",
    "answer": "95"
  },
  {
    "question": "Câu 829: 85 × 80 = ?",
    "answer": "6800"
  },
  {
    "question": "Câu 830: 78 × 44 = ?",
    "answer": "3432"
  },
  {
    "question": "Câu 831: 6 + 4 = ?",
    "answer": "10"
  },
  {
    "question": "Câu 832: 6 × 83 = ?",
    "answer": "498"
  },
  {
    "question": "Câu 833: 34 + 84 = ?",
    "answer": "118"
  },
  {
    "question": "Câu 834: 99 - 74 = ?",
    "answer": "25"
  },
  {
    "question": "Câu 835: 80 + 82 = ?",
    "answer": "162"
  },
  {
    "question": "Câu 836: 64 × 81 = ?",
    "answer": "5184"
  },
  {
    "question": "Câu 837: 83 - 38 = ?",
    "answer": "45"
  },
  {
    "question": "Câu 838: 62 × 32 = ?",
    "answer": "1984"
  },
  {
    "question": "Câu 839: 52 - 39 = ?",
    "answer": "13"
  },
  {
    "question": "Câu 840: 10 + 89 = ?",
    "answer": "99"
  },
  {
    "question": "Câu 841: 57 - 21 = ?",
    "answer": "36"
  },
  {
    "question": "Câu 842: 62 + 60 = ?",
    "answer": "122"
  },
  {
    "question": "Câu 843: 44 + 78 = ?",
    "answer": "122"
  },
  {
    "question": "Câu 844: 92 - 41 = ?",
    "answer": "51"
  },
  {
    "question": "Câu 845: 94 - 45 = ?",
    "answer": "49"
  },
  {
    "question": "Câu 846: 98 - 17 = ?",
    "answer": "81"
  },
  {
    "question": "Câu 847: 66 + 72 = ?",
    "answer": "138"
  },
  {
    "question": "Câu 848: 41 - 31 = ?",
    "answer": "10"
  },
  {
    "question": "Câu 849: 35 - 16 = ?",
    "answer": "19"
  },
  {
    "question": "Câu 850: 32 + 19 = ?",
    "answer": "51"
  },
  {
    "question": "Câu 851: 38 - 7 = ?",
    "answer": "31"
  },
  {
    "question": "Câu 852: 79 + 54 = ?",
    "answer": "133"
  },
  {
    "question": "Câu 853: 21 × 42 = ?",
    "answer": "882"
  },
  {
    "question": "Câu 854: 93 + 41 = ?",
    "answer": "134"
  },
  {
    "question": "Câu 855: 98 - 21 = ?",
    "answer": "77"
  },
  {
    "question": "Câu 856: 66 - 60 = ?",
    "answer": "6"
  },
  {
    "question": "Câu 857: 40 + 64 = ?",
    "answer": "104"
  },
  {
    "question": "Câu 858: 12 × 51 = ?",
    "answer": "612"
  },
  {
    "question": "Câu 859: 59 + 31 = ?",
    "answer": "90"
  },
  {
    "question": "Câu 860: 75 + 46 = ?",
    "answer": "121"
  },
  {
    "question": "Câu 861: 37 - 7 = ?",
    "answer": "30"
  },
  {
    "question": "Câu 862: 77 × 84 = ?",
    "answer": "6468"
  },
  {
    "question": "Câu 863: 61 × 37 = ?",
    "answer": "2257"
  },
  {
    "question": "Câu 864: 14 - 2 = ?",
    "answer": "12"
  },
  {
    "question": "Câu 865: 18 × 34 = ?",
    "answer": "612"
  },
  {
    "question": "Câu 866: 98 - 47 = ?",
    "answer": "51"
  },
  {
    "question": "Câu 867: 47 - 6 = ?",
    "answer": "41"
  },
  {
    "question": "Câu 868: 7 × 73 = ?",
    "answer": "511"
  },
  {
    "question": "Câu 869: 25 × 47 = ?",
    "answer": "1175"
  },
  {
    "question": "Câu 870: 37 - 10 = ?",
    "answer": "27"
  },
  {
    "question": "Câu 871: 65 × 58 = ?",
    "answer": "3770"
  },
  {
    "question": "Câu 872: 36 × 80 = ?",
    "answer": "2880"
  },
  {
    "question": "Câu 873: 79 + 16 = ?",
    "answer": "95"
  },
  {
    "question": "Câu 874: 51 - 13 = ?",
    "answer": "38"
  },
  {
    "question": "Câu 875: 72 - 44 = ?",
    "answer": "28"
  },
  {
    "question": "Câu 876: 97 + 19 = ?",
    "answer": "116"
  },
  {
    "question": "Câu 877: 78 - 66 = ?",
    "answer": "12"
  },
  {
    "question": "Câu 878: 65 + 6 = ?",
    "answer": "71"
  },
  {
    "question": "Câu 879: 5 × 18 = ?",
    "answer": "90"
  },
  {
    "question": "Câu 880: 43 × 61 = ?",
    "answer": "2623"
  },
  {
    "question": "Câu 881: 59 × 20 = ?",
    "answer": "1180"
  },
  {
    "question": "Câu 882: 66 - 18 = ?",
    "answer": "48"
  },
  {
    "question": "Câu 883: 79 + 41 = ?",
    "answer": "120"
  },
  {
    "question": "Câu 884: 51 × 79 = ?",
    "answer": "4029"
  },
  {
    "question": "Câu 885: 76 - 39 = ?",
    "answer": "37"
  },
  {
    "question": "Câu 886: 65 × 66 = ?",
    "answer": "4290"
  },
  {
    "question": "Câu 887: 63 × 91 = ?",
    "answer": "5733"
  },
  {
    "question": "Câu 888: 39 + 61 = ?",
    "answer": "100"
  },
  {
    "question": "Câu 889: 48 × 43 = ?",
    "answer": "2064"
  },
  {
    "question": "Câu 890: 15 × 54 = ?",
    "answer": "810"
  },
  {
    "question": "Câu 891: 40 × 93 = ?",
    "answer": "3720"
  },
  {
    "question": "Câu 892: 81 × 4 = ?",
    "answer": "324"
  },
  {
    "question": "Câu 893: 61 × 34 = ?",
    "answer": "2074"
  },
  {
    "question": "Câu 894: 100 × 75 = ?",
    "answer": "7500"
  },
  {
    "question": "Câu 895: 30 + 93 = ?",
    "answer": "123"
  },
  {
    "question": "Câu 896: 75 + 62 = ?",
    "answer": "137"
  },
  {
    "question": "Câu 897: 68 × 81 = ?",
    "answer": "5508"
  },
  {
    "question": "Câu 898: 100 - 80 = ?",
    "answer": "20"
  },
  {
    "question": "Câu 899: 19 + 88 = ?",
    "answer": "107"
  },
  {
    "question": "Câu 900: 5 × 74 = ?",
    "answer": "370"
  },
  {
    "question": "Câu 901: 15 + 25 = ?",
    "answer": "40"
  },
  {
    "question": "Câu 902: 57 - 41 = ?",
    "answer": "16"
  },
  {
    "question": "Câu 903: 20 × 53 = ?",
    "answer": "1060"
  },
  {
    "question": "Câu 904: 27 × 53 = ?",
    "answer": "1431"
  },
  {
    "question": "Câu 905: 100 - 79 = ?",
    "answer": "21"
  },
  {
    "question": "Câu 906: 95 + 94 = ?",
    "answer": "189"
  },
  {
    "question": "Câu 907: 91 × 18 = ?",
    "answer": "1638"
  },
  {
    "question": "Câu 908: 72 - 27 = ?",
    "answer": "45"
  },
  {
    "question": "Câu 909: 85 × 62 = ?",
    "answer": "5270"
  },
  {
    "question": "Câu 910: 49 + 41 = ?",
    "answer": "90"
  },
  {
    "question": "Câu 911: 69 - 59 = ?",
    "answer": "10"
  },
  {
    "question": "Câu 912: 70 × 46 = ?",
    "answer": "3220"
  },
  {
    "question": "Câu 913: 99 × 93 = ?",
    "answer": "9207"
  },
  {
    "question": "Câu 914: 89 - 83 = ?",
    "answer": "6"
  },
  {
    "question": "Câu 915: 79 + 62 = ?",
    "answer": "141"
  },
  {
    "question": "Câu 916: 32 × 36 = ?",
    "answer": "1152"
  },
  {
    "question": "Câu 917: 39 - 29 = ?",
    "answer": "10"
  },
  {
    "question": "Câu 918: 99 × 37 = ?",
    "answer": "3663"
  },
  {
    "question": "Câu 919: 27 × 89 = ?",
    "answer": "2403"
  },
  {
    "question": "Câu 920: 63 - 41 = ?",
    "answer": "22"
  },
  {
    "question": "Câu 921: 45 × 72 = ?",
    "answer": "3240"
  },
  {
    "question": "Câu 922: 36 + 37 = ?",
    "answer": "73"
  },
  {
    "question": "Câu 923: 74 × 87 = ?",
    "answer": "6438"
  },
  {
    "question": "Câu 924: 51 - 49 = ?",
    "answer": "2"
  },
  {
    "question": "Câu 925: 99 - 19 = ?",
    "answer": "80"
  },
  {
    "question": "Câu 926: 6 × 37 = ?",
    "answer": "222"
  },
  {
    "question": "Câu 927: 45 - 11 = ?",
    "answer": "34"
  },
  {
    "question": "Câu 928: 84 × 33 = ?",
    "answer": "2772"
  },
  {
    "question": "Câu 929: 62 + 28 = ?",
    "answer": "90"
  },
  {
    "question": "Câu 930: 69 × 35 = ?",
    "answer": "2415"
  },
  {
    "question": "Câu 931: 90 + 35 = ?",
    "answer": "125"
  },
  {
    "question": "Câu 932: 14 × 79 = ?",
    "answer": "1106"
  },
  {
    "question": "Câu 933: 76 + 31 = ?",
    "answer": "107"
  },
  {
    "question": "Câu 934: 7 × 86 = ?",
    "answer": "602"
  },
  {
    "question": "Câu 935: 29 + 82 = ?",
    "answer": "111"
  },
  {
    "question": "Câu 936: 13 - 7 = ?",
    "answer": "6"
  },
  {
    "question": "Câu 937: 92 - 43 = ?",
    "answer": "49"
  },
  {
    "question": "Câu 938: 13 + 88 = ?",
    "answer": "101"
  },
  {
    "question": "Câu 939: 1 + 71 = ?",
    "answer": "72"
  },
  {
    "question": "Câu 940: 84 - 53 = ?",
    "answer": "31"
  },
  {
    "question": "Câu 941: 62 + 84 = ?",
    "answer": "146"
  },
  {
    "question": "Câu 942: 97 - 37 = ?",
    "answer": "60"
  },
  {
    "question": "Câu 943: 37 + 83 = ?",
    "answer": "120"
  },
  {
    "question": "Câu 944: 99 × 12 = ?",
    "answer": "1188"
  },
  {
    "question": "Câu 945: 74 × 30 = ?",
    "answer": "2220"
  },
  {
    "question": "Câu 946: 95 + 93 = ?",
    "answer": "188"
  },
  {
    "question": "Câu 947: 23 + 54 = ?",
    "answer": "77"
  },
  {
    "question": "Câu 948: 51 - 5 = ?",
    "answer": "46"
  },
  {
    "question": "Câu 949: 96 - 24 = ?",
    "answer": "72"
  },
  {
    "question": "Câu 950: 5 - 2 = ?",
    "answer": "3"
  },
  {
    "question": "Câu 951: 73 + 78 = ?",
    "answer": "151"
  },
  {
    "question": "Câu 952: 43 - 37 = ?",
    "answer": "6"
  },
  {
    "question": "Câu 953: 83 × 70 = ?",
    "answer": "5810"
  },
  {
    "question": "Câu 954: 64 × 18 = ?",
    "answer": "1152"
  },
  {
    "question": "Câu 955: 60 + 35 = ?",
    "answer": "95"
  },
  {
    "question": "Câu 956: 15 + 43 = ?",
    "answer": "58"
  },
  {
    "question": "Câu 957: 94 × 59 = ?",
    "answer": "5546"
  },
  {
    "question": "Câu 958: 33 + 92 = ?",
    "answer": "125"
  },
  {
    "question": "Câu 959: 95 - 2 = ?",
    "answer": "93"
  },
  {
    "question": "Câu 960: 38 × 73 = ?",
    "answer": "2774"
  },
  {
    "question": "Câu 961: 97 + 25 = ?",
    "answer": "122"
  },
  {
    "question": "Câu 962: 82 - 79 = ?",
    "answer": "3"
  },
  {
    "question": "Câu 963: 66 - 55 = ?",
    "answer": "11"
  },
  {
    "question": "Câu 964: 12 × 52 = ?",
    "answer": "624"
  },
  {
    "question": "Câu 965: 13 + 24 = ?",
    "answer": "37"
  },
  {
    "question": "Câu 966: 62 + 42 = ?",
    "answer": "104"
  },
  {
    "question": "Câu 967: 34 - 1 = ?",
    "answer": "33"
  },
  {
    "question": "Câu 968: 58 - 31 = ?",
    "answer": "27"
  },
  {
    "question": "Câu 969: 43 × 39 = ?",
    "answer": "1677"
  },
  {
    "question": "Câu 970: 93 + 74 = ?",
    "answer": "167"
  },
  {
    "question": "Câu 971: 84 - 34 = ?",
    "answer": "50"
  },
  {
    "question": "Câu 972: 89 + 31 = ?",
    "answer": "120"
  },
  {
    "question": "Câu 973: 86 - 16 = ?",
    "answer": "70"
  },
  {
    "question": "Câu 974: 40 - 21 = ?",
    "answer": "19"
  },
  {
    "question": "Câu 975: 88 × 65 = ?",
    "answer": "5720"
  },
  {
    "question": "Câu 976: 99 × 40 = ?",
    "answer": "3960"
  },
  {
    "question": "Câu 977: 82 - 16 = ?",
    "answer": "66"
  },
  {
    "question": "Câu 978: 48 + 79 = ?",
    "answer": "127"
  },
  {
    "question": "Câu 979: 29 - 18 = ?",
    "answer": "11"
  },
  {
    "question": "Câu 980: 20 × 59 = ?",
    "answer": "1180"
  },
  {
    "question": "Câu 981: 78 - 48 = ?",
    "answer": "30"
  },
  {
    "question": "Câu 982: 90 - 71 = ?",
    "answer": "19"
  },
  {
    "question": "Câu 983: 97 × 69 = ?",
    "answer": "6693"
  },
  {
    "question": "Câu 984: 28 + 98 = ?",
    "answer": "126"
  },
  {
    "question": "Câu 985: 88 × 97 = ?",
    "answer": "8536"
  },
  {
    "question": "Câu 986: 68 - 11 = ?",
    "answer": "57"
  },
  {
    "question": "Câu 987: 91 - 68 = ?",
    "answer": "23"
  },
  {
    "question": "Câu 988: 10 + 73 = ?",
    "answer": "83"
  },
  {
    "question": "Câu 989: 8 × 71 = ?",
    "answer": "568"
  },
  {
    "question": "Câu 990: 26 × 74 = ?",
    "answer": "1924"
  },
  {
    "question": "Câu 991: 22 - 20 = ?",
    "answer": "2"
  },
  {
    "question": "Câu 992: 67 + 57 = ?",
    "answer": "124"
  },
  {
    "question": "Câu 993: 88 × 27 = ?",
    "answer": "2376"
  },
  {
    "question": "Câu 994: 75 + 63 = ?",
    "answer": "138"
  },
  {
    "question": "Câu 995: 66 + 58 = ?",
    "answer": "124"
  },
  {
    "question": "Câu 996: 59 × 17 = ?",
    "answer": "1003"
  },
  {
    "question": "Câu 997: 54 × 59 = ?",
    "answer": "3186"
  },
  {
    "question": "Câu 998: 72 - 8 = ?",
    "answer": "64"
  },
  {
    "question": "Câu 999: 87 × 40 = ?",
    "answer": "3480"
  },
  {
    "question": "Câu 1000: 51 - 3 = ?",
    "answer": "48"
  }
];
